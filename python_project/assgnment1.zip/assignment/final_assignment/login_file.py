from tkinter import *
from tkinter import messagebox
import save



class login:
    def __init__(self, screen):
        self.screen = screen
        self.screen.geometry('550x370+500+200')
        global backimage
        global userr
        global pasw
        userr=StringVar()
        pasw=StringVar()

        self.backimage = PhotoImage(file='login.png')
        self.background_lb = Label(self.screen, image=self.backimage)
        self.background_lb.place(x=0, y=0)
        self.title = Label(self.screen, text='LOGIN SYSTEM', font='Arial 20 bold', bg='black', fg='white')
        self.title.place(x=125, y=6)

        self.username_ent = Entry(self.screen, font='Arial 15 bold', bg='black', fg='white',textvariable=userr)
        self.username_ent.insert(0, 'Enter username')
        self.anti=self.username_ent.bind('<Button-1>',self.click_btn)
        self.username_ent.place(x=100, y=100)
        self.psw_ent = Entry(self.screen, font='Arial 15 bold', bg='black', fg='white',textvariable=pasw)
        self.psw_ent.insert(0, 'Enter password')
        self.ans=self.psw_ent.bind('<Button-1>',self.click_btn1)
        self.psw_ent.place(x=100, y=150)
        self.log_btn = Button(self.screen, text='Login', bg='sky blue',command=lambda:self.call())
        self.log_btn.place(x=160, y=200)
        self.reg_lb = Label(self.screen, text="Don't have One ? ", bg='black', fg='white', font='Arial 8 bold')
        self.reg_lb.place(x=160, y=250)
        self.reg_btn = Button(self.screen, font='Arial 8 bold', text='Createone', bd=0, bg='black', fg='sky blue',command=lambda:self.sign())
        self.reg_btn.place(x=265, y=250)

        self.reset_btn = Button(self.screen, text='Reset', bg='sky blue',command=lambda:self.multifun())
        self.reset_btn.place(x=240, y=200)
    def call(self):
        save.plan.load(self,userr.get(),pasw.get())



    def multifun(self):
        self.username_ent.delete(0,END)
        self.psw_ent.delete(0,END)

    def click_btn(self,event):
        self.username_ent.delete(0, 'end')
        self.username_ent.unbind('<Button-1>',self.anti)

    def click_btn1(self,event):
        self.psw_ent.delete(0, 'end')
        self.psw_ent.unbind('<Button-1>',self.ans)
    def sign(self):
        self.screen.destroy()
        import user_register
        wn = Tk(className='Register')
        fun = user_register.register(wn)
        wn.resizable(0, 0)


screen = Tk(className='LoginForm')
call = login(screen)
screen.resizable(0, 0)
screen.mainloop()
