import pickle
import os
from tkinter import messagebox
from tkinter import *
le = os.path.getsize('Z:\\Python_class\\final_assignment\\employee_register.txt')
d = {}
class saving:
    def insert(self,id,name,age,address,contact,dep):
        global d
        di = {id:[name,age,address,contact,dep]}
        if (len(id) and len(name) and len(age) and len(address) and len(contact) and len(dep)) >0:
            if le > 0:
                with open('employee_register.txt','rb+') as f:
                    d = pickle.load(f)
                    d.update(di)
                    print(d)
                    f.seek(0)
                    pickle.dump(d, f)
                    messagebox.showinfo('instruction','data saved successfully')

            else:
                f = open('employee_register.txt', 'wb')
                d.update(di)
                pickle.dump(d, f)
                messagebox.showinfo('instruction', 'data saved successfully')
                f.close()
            return
        else:
            messagebox.showinfo('Information','Fill all the fields')
