from tkinter import *
from tkinter import messagebox
import save



class register:

    def __init__(self, wn):
        self.wn = wn
        self.wn.title = 'Register'
        self.wn.geometry('450x550+550+130')
        # variable declaration
        global bg
        global regicon
        global exit
        global username
        global password
        global email
        global con_psw
        var1 = IntVar()


        bg=PhotoImage(file='user_register.png')
        back_lb=Label(self.wn,image=bg)
        back_lb.place(x=0,y=0)
        regicon = PhotoImage(file="REG1.png")
        # =====text variables
        username = StringVar()
        password = StringVar()
        email=StringVar()
        pasw_entry = StringVar()
        pasw_con_entry = StringVar()
        con_psw=StringVar()
        self.title = Label(self.wn, text='CREATE AN ACCOUNT ', font='Arial 18 bold', bg='black', fg='white')
        self.title.place(x=70,y=10)

        self.username_ent = Entry(self.wn, font='Arial 20 bold', bg='black', fg='white',textvariable=username)
        self.username_ent.insert(0, 'Username')
        self.add = self.username_ent.bind('<Button-1>', self.click_btn)
        self.username_ent.place(x=65,y=100)
        self.password_ent = Entry(self.wn, font='Arial 20 bold', bg='black', fg='white',textvariable=password)
        self.password_ent.insert(0, 'Password')
        self.pasw=self.password_ent.bind('<Button-1>',self.click_btn1)
        self.password_ent.place(x=65,y=150)
        self.con_ent = Entry(self.wn, font='Arial 20 bold', bg='black', fg='white',textvariable=con_psw)
        self.con_ent.insert(0, 'Confirm Password')
        self.con=self.con_ent.bind('<Button-1>',self.click_btn2)
        self.con_ent.place(x=65,y=200)
        self.email_ent = Entry(self.wn, font='Arial 20 bold', bg='black', fg='white',textvariable=email)
        self.email_ent.insert(0, 'Email')
        self.emm=self.email_ent.bind('<Button-1>',self.click_btn3)
        self.email_ent.place(x=65,y=250)
        self.btn_register = Button(self.wn, image=regicon,bg='black',fg='white', command=lambda:save.plan.insert(self,username.get(),password.get(),email.get(),con_psw.get()))
        self.btn_register.place(x=80, y=432)
        self.btn_signin = Button(self.wn, bd=0, text='Sign-in', width=-10, font='Arial 15 bold', fg='green',bg='black')
        self.terms_btn = Button(self.wn, bd=0, text='terms', width=-10, font='Arial 10 bold', fg='green',bg='black').place(x=169, y=369)
        self.agree_lb = Label(self.wn, text='I agree to all', font='Arial 10 bold',bg='black',fg='white')
        self.agree_lb.place(x=90, y=370)
        self.click_btn=Checkbutton(self.wn,bg='black')
        self.click_btn.place(x=60,y=370)
        self.exit_btn = Button(self.wn, font='Arial,1,bold', text='Back',bg='black',fg='white', command=lambda: self.retun())
        self.exit_btn.place(x=370, y=10)
    def click_btn(self,event):
        self.username_ent.delete(0, END)
        self.username_ent.unbind('<Button-1>',self.add)
    def click_btn1(self,event):
        self.password_ent.delete(0, END)
        self.password_ent.unbind('<Button-1>',self.pasw)
    def click_btn2(self,event):
        self.con_ent.delete(0, END)
        self.con_ent.unbind('<Button-1>',self.con)
    def click_btn3(self,event):
        self.email_ent.delete(0, END)
        self.email_ent.unbind('<Button-1>',self.emm)


    def retun(self):
        self.wn.destroy()
        import login_file










