import pickle
import os
from tkinter import messagebox
le = os.path.getsize('Z:\\Python_class\\final_assignment\\abc.txt')
d = {}
class plan:
    def insert(self,uname,pasword,email,con_psw):
        global d
        di = {uname:[pasword,email]}
        if len(uname) and len(pasword) > 0:
            if pasword != con_psw:
                messagebox.showwarning('Warning', 'Password mismatch')
            else:
                if le > 0:
                    with open('abc.txt', 'rb+') as f:
                        d = pickle.load(f)
                        d.update(di)
                        f.seek(0)
                        pickle.dump(d, f)
                        messagebox.showinfo('instruction', 'data saved successfully')

                else:
                    f = open('abc.txt', 'wb')
                    d.update(di)
                    pickle.dump(d, f)
                    messagebox.showinfo('Congratulation', 'Data saved succesfully')
                    f.close()

        else:
            messagebox.showinfo('Information', 'Please fill all the fields')

    def load(self,uname,pasword):
        if (len(uname) and len(pasword))==0:
            messagebox.showinfo('Information', 'Please fill the fields')
        else:
            le = os.path.getsize('Z:\\Python_class\\final_assignment\\abc.txt')
            if le > 0:
                f = open('abc.txt', 'rb')
                ld = pickle.load(f)
                lm=ld.keys()
                for i in lm:
                    if i==uname:
                        j=ld[i][0]
                        if j==pasword:
                            messagebox.showinfo('Congratulations ','Login Successfull')
                            f.close()
                            self.screen.destroy()
                            import Employee_Form
                            return

                else:
                    messagebox.showwarning('Warning', 'Username or Password is wrong')
                    f.close()
            else:
                messagebox.showinfo('Infromation','file is empty')



