from tkinter import *
from tkinter import messagebox
import save_two
import os
import pickle







class App(Tk):
    def __init__(self, *args, **kwargs):
        Tk.__init__(self, *args, **kwargs)
        # Setup Frame
        container = Frame(self)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}

        for F in (MainMenu, Employee_form, department,Details):
            frame = F(container, self)
            self.frames[F] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame(MainMenu)

    def show_frame(self, context):
        frame = self.frames[context]
        frame.tkraise()
        if context == Employee_form:
            self.geometry('420x530+520+100')
        elif context == department:
            self.geometry('350x300+520+100')
        else:
            self.geometry('300x300+550+200')


class Employee_form(Frame):
    def __init__(self, parent, controller):
        Frame.__init__(self, parent)
        global firstname
        global lastname
        global age
        global address
        global id
        global contact

        self.backimage = PhotoImage(file='fourfifty.png')
        self.background_lb = Label(self, image=self.backimage)
        self.background_lb.place(x=0, y=0)
        name=StringVar()
        age=IntVar()
        address=StringVar()
        id=IntVar()
        contact=IntVar()

        self.name_lb = Label(self, text='EMPLOYEE REGISTER', font='Arial 20 bold',bd=0,bg='black',fg='white')
        self.name_lb.place(x=55, y=0)
        self.id_lb = Label(self, text='ID', font='Arial 15 bold', bd=0,bg='black',fg='white')
        self.id_lb.place(x=50, y=65)
        self.id_ent = Entry(self, font='Arial 15 bold', textvariable=id,bg='black',fg='white')
        self.id_ent.place(x=150, y=65)
        self.nam_lb=Label(self,text='Name',font='Arial 15 bold',bd=0,bg='black',fg='white')
        self.nam_lb.place(x=50,y=115)
        self.nam_ent=Entry(self,font='Arial 15 bold',textvariable=name,bg='black',fg='white')
        self.nam_ent.place(x=150,y=115)
        self.age_lb = Label(self, text='AGE', font='Arial 15 bold', bd=0,bg='black',fg='white')
        self.age_lb.place(x=50, y=165)
        self.ad_lb = Label(self, text='ADDRESS', font='Arial 15 bold', bd=0,bg='black',fg='white')
        self.ad_lb.place(x=50, y=220)
        self.age_ent = Entry(self, font='Arial 15 bold',textvariable=age,bg='black',fg='white')
        self.age_ent.place(x=150, y=165)
        self.ad_ent = Entry(self, font='Arial 15 bold',textvariable=address,bg='black',fg='white')
        self.ad_ent.place(x=150, y=220)

        self.contact_lb = Label(self, text='CONTACT', font='Arial 10 bold', bd=0,bg='black',fg='white')
        self.contact_lb.place(x=50, y=270)

        self.contact_ent = Entry(self, font='Arial 15 bold',textvariable=contact,bg='black',fg='white')
        self.contact_ent.place(x=150, y=270)
        self.gen_lb = Label(self, text='GENDER:', font='Arial 15 bold',bg='black',fg='white')
        self.gen_lb.place(x=50, y=305)

        self.male_lb = Label(self, text='MALE', font='Arial 11 bold',bg='black',fg='white')
        self.male_lb.place(x=120, y=305)
        self.female_lb = Label(self, text='FEMALE', font='Arial 11 bold',bg='black',fg='white')

        self.female_lb.place(x=200, y=305)

        self.var = IntVar()
        self.male_btn = Radiobutton(self, variable=self.var, value=1,bd=0,bg='black',fg='white')
        self.male_btn.place(x=175, y=305)
        self.female_btn = Radiobutton(self, variable=self.var, value=2,bd=0,bg='black',fg='white')
        self.female_btn.place(x=280, y=305)

        self.departments()

        self.submit_btn = Button(self, text='Submit', font='Arial 15 bold',bg='grey',
                                 command=lambda: save_two.saving.insert(self, self.id_ent.get(),self.nam_ent.get(),
                                                                        self.age_ent.get(), self.ad_ent.get(),
                                                                        self.contact_ent.get(), variable.get()))
        self.submit_btn.place(x=330, y=450)
        self.reset_btn = Button(self, text='Reset', font='Arial 15 bold',command=self.reset,bg='grey')
        self.reset_btn.place(x=260, y=450)
        self.back_btn = Button(self, text='Back', font='Arial 10 bold', command=lambda: controller.show_frame(MainMenu),bg='grey')
        self.back_btn.place(x=370, y=3)
    def departments(self):
        global variable
        variable = StringVar()
        le = os.path.getsize('Z:\\Python_class\\final_assignment\\dept.txt')
        global d
        d = {}
        if le > 0:
            with open("dept.txt", 'rb+') as f:
                global ld
                ld = pickle.load(f)
                d.update(ld)
                lm = ld.keys()
                l = []
                for i in lm:
                    l.append(i)

            variable.set("choose one department")
            department_drop_down = OptionMenu(self, variable, *l)
            department_drop_down.place(x=50, y=350)

    def reset(self):
        self.id_ent.delete(0, END)
        self.nam_ent.delete(0, END)
        self.age_ent.delete(0, END)
        self.ad_ent.delete(0, END)
        self.contact_ent.delete(0, END)



class department(Frame):
    def __init__(self, parent, controller):
        Frame.__init__(self, parent)
        self.code=IntVar()
        self.depname=StringVar()
        self.loca=StringVar()
        self.bac_image=PhotoImage(file='dep_image.png')
        self.background=Label(self,image=self.bac_image)
        self.background.place(x=0,y=0)


        self.dept_lb = Label(self, text='Department Code', font='Arial 20 bold',bd=0,bg='black',fg='white')
        self.dept_lb.place(x=65, y=30)
        self.dept_ent = Entry(self, font='Arial 15 bold',textvariable=self.code,bg='black',fg='white')
        self.dept_ent.place(x=65, y=60)
        self.dept_name = Label(self, text='Department Name', font='Arial 20 bold',bd=0,bg='black',fg='white')
        self.dept_name.place(x=62, y=90)
        self.dept_nameent = Entry(self, font='Arial 15 bold',textvariable=self.depname,bg='black',fg='white')
        self.dept_nameent.place(x=65, y=125)
        self.dept_loca = Label(self, text='Department Location', font='Arial 20 bold',bd=0,bg='black',fg='white')
        self.dept_loca.place(x=62, y=150)
        self.dept_locaent = Entry(self, font='Arial 15 bold',textvariable=self.loca,bg='black',fg='white')
        self.dept_locaent.place(x=65, y=180)
        self.submit_btn = Button(self, text='SUBMIT', font='Arial 10 bold',command=self.submit,bd=0,bg='black',fg='white')
        self.submit_btn.place(x=190, y=220)
        self.reset_btn = Button(self, text='Reset', font='Arial 10 bold', command=self.reset_btnclick,bd=0,bg='black',fg='white')
        self.reset_btn.place(x=250, y=220)
        self.back_btn = Button(self, text='Back', font='Arial 10 bold', command=lambda: controller.show_frame(MainMenu),bd=0,bg='black',fg='white')
        self.back_btn.place(x=290, y=5)
    def submit(self):
        global d
        depname=self.depname.get()
        depcode=self.dept_ent.get()
        deploca=self.loca.get()
        di = {depname:[depcode,deploca]}
        le=os.path.getsize('Z:\\Python_class\\final_assignment\\dept.txt')
        d={}
        if (len(depname) and len(depcode) and len(deploca))>0:
            if le > 0:
                with open('dept.txt', 'rb+') as f:
                    d = pickle.load(f)
                    d.update(di)
                    f.seek(0)
                    pickle.dump(d, f)
                    messagebox.showinfo('instruction', 'data saved successfully')

            else:
                f = open('dept.txt', 'wb')
                d.update(di)
                pickle.dump(d, f)
                messagebox.showinfo('instruction', 'data saved successfully')
                f.close()
            return
        else:
            messagebox.showinfo('Information', 'Fill all the fields')

    def reset_btnclick(self):
        self.dept_ent.delete(0, END)
        self.dept_nameent.delete(0, END)
        self.dept_locaent.delete(0,END)


class MainMenu(Frame):
    def __init__(self, parent, controller):
        Frame.__init__(self, parent)

        self.backimage = PhotoImage(file='main_menu.png')
        self.background_lb = Label(self, image=self.backimage)
        self.background_lb.place(x=0, y=0)

        self.lb = Label(self, text='MainMenu', font='Arial 20 bold',bd=0,bg='black',fg='white')
        self.lb.place(x=80, y=5)
        self.btn = Button(self, text='Add Department', font='Arial 15 bold',
                          command=lambda: controller.show_frame(department),bd=0,bg='black',fg='white')
        self.btn.place(x=65, y=70)
        self.btn2 = Button(self, text='Employment Form', font='Arial 15 bold',
                           command=lambda: controller.show_frame(Employee_form),bd=0,bg='black',fg='white')
        self.btn2.place(x=55, y=140)
        self.btn3 = Button(self, text='Exit', font='Arial 10 bold', command=self.exit_click,bd=0,bg='black',fg='white')
        self.btn3.place(x=250, y=5)


        self.btn3 = Button(self, text='Employee Details', font='Arial 15 bold',command=self.go,bd=0,bg='black',fg='white')
        self.btn3.place(x=60, y=210)




    def go(self):
        import show




    def exit_click(self):
        a = messagebox.askquestion('Exit', 'Do you really wanna exit??')
        if a == 'yes':
            self.quit()
class Details(Frame):
    def __init__(self,parent,controller):
        Frame.__init__(self,parent)

        self.backimage = PhotoImage(file='main_menu.png')
        self.background_lb = Label(self, image=self.backimage)
        self.background_lb.place(x=0, y=0)
        btn1=Button(self,font='Arial 10 bold',text='Back',command=lambda:controller.show_frame(MainMenu),bd=0,bg='black',fg='white')
        btn1.place(x=255,y=0)
        lb=Label(self)

app = App()
app.mainloop()
