from tkinter import *
import os
import pickle
import save_two
from tkinter import messagebox
class call:
    def __init__(self,wn):
        self.wn=wn
        self.lb=Label(self.wn,text='hi')
        self.lb.place(x=10,y=10)
        le = os.path.getsize('Z:\\Python_class\\final_assignment\\employee_register.txt')
        global d
        d={}
        if le > 0:
            with open('employee_register.txt', 'rb+') as f:
                global ld
                ld = pickle.load(f)
                d.update(ld)
                lm = ld.keys()
                print(lm)
                r=int(0)
                frame = Frame(self.wn, background='BLACK', borderwidth=1, relief=SUNKEN)
                self.butname = Label(self.wn, text=(
                    'ID'), font='Arial 20 bold', borderwidth=3).grid(
                    row=0, column=1)
                self.butname = Label(self.wn, text=(
                    'Name'), font='Arial 20 bold', borderwidth=3).grid(
                    row=0, column=2)
                self.butname = Label(self.wn, text=(
                    'Age'), font='Arial 20 bold', borderwidth=3).grid(
                    row=0, column=3)
                self.butname = Label(self.wn, text=(
                    'Address'), font='Arial 20 bold', borderwidth=3 ,).grid(
                    row=0, column=4)
                self.butname = Label(self.wn, text=(
                    'Contact No'), font='Arial 20 bold', borderwidth=3).grid(
                    row=0, column=5)
                self.butname = Label(self.wn, text=(
                    'Department Name'), font='Arial 20 bold', borderwidth=3).grid(
                    row=0, column=6)

                for i in lm:
                    r=r+1

                    a = d[i][0]
                    b = d[i][1]
                    c = d[i][2]
                    f = d[i][3]
                    e = d[i][4]



                    self.butname = 'Employee' + str(i)
                    #for j in range(1):

                    self.butname = Label(self.wn, text=(
                    i), font='Arial 20 ', borderwidth=3).grid(
                    row=r, column=1)
                    self.butname = Label(self.wn, text=(
                        a), font='Arial 20 ', borderwidth=3).grid(
                        row=r, column=2)
                    self.butname = Label(self.wn, text=(
                        b), font='Arial 20 ', borderwidth=3).grid(
                        row=r, column=3)
                    self.butname = Label(self.wn, text=(
                        c), font='Arial 20 ', borderwidth=3).grid(
                        row=r, column=4)
                    self.butname = Label(self.wn, text=(
                        f), font='Arial 20 ', borderwidth=3).grid(
                        row=r, column=5)
                    self.butname = Label(self.wn, text=(
                        e), font='Arial 20 ', borderwidth=3).grid(
                        row=r, column=6)




wn = Tk()
call(wn)
wn.mainloop()