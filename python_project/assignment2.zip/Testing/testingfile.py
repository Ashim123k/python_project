import unittest
from Files.Category_Files import *
from Files.Brand_File import *
from Files.Itemdetails_Files import *
from Files.ent_file import *

class mytest(unittest.TestCase):
    cat=cat_op()
    brand=brand_op()
    item=details()
    quote=MyDb()
    file=search()

    def test_cat(self):
        result=self.cat.add_cat('ashim','all ok')
        self.assertTrue(result)
    def test_brand(self):
        result=self.brand.update_brand(1,'Beer','all ok')
        self.assertTrue(result)
    def test_item_details(self):
        result=self.item.items_details(12,11,13,'ALl ok',[(2,11)])
        self.assertTrue(result)
    def test_query(self):
        qry='SELECT * FROM category'
        result=self.quote.show(qry)
        self.assertTrue(result)
    def test_ent_file(self):
        result=self.file.sale_search('h')
        self.assertTrue(result)
    def test_false_ent_file(self):
        result=self.file.sale_search('beer')
        self.assertFalse(result)





