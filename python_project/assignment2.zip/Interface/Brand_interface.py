from tkinter import *
from Files.Brand_File import brand_op
from tkinter import ttk
from tkinter import messagebox
bran=brand_op()
class Brand:
    def __init__(self,wn):
        self.wn=wn
        self.wn.geometry('450x450+200+200')
        self.wn.title('Add new brand')
        global index
        index=''
        #######LABEL##############
        self.Brand = Label(self.wn, text='* Brand Name',font='Arial 11 bold').place(x=30,y=10)
        self.remarks = Label(self.wn, text='Remarks', font='Arial 11 bold').place(x=30, y=60)
        ######Entry#############
        self.brand_ent = Entry(self.wn, font='Arial 17 bold',bg='orange',fg='white')
        self.brand_ent.place(x=170, y=10)
        self.remarks_ent = Entry(self.wn, font='Arial 18 bold',bg='orange',fg='white')
        self.remarks_ent.place(x=170, y=60)
        #####TREEVIEW#######
        global brand_tree
        brand_tree=ttk.Treeview(self.wn,columns=('id','Brand Name','Remarks'))
        brand_tree.place(x=0,y=170)
        brand_tree['show']='headings'
        brand_tree.column('id',width=90)
        brand_tree.column('Brand Name', width=140)
        brand_tree.column('Remarks', width=215)
        brand_tree.heading('id',text='ID')
        brand_tree.heading('Brand Name',text='Brand Name')
        brand_tree.heading('Remarks',text='Remarks')

        #####BUTTON############
        self.new_btn=Button(self.wn,font='Arial 9 ',text='New',width=9,height=2,relief=GROOVE,command=self.new_brand)
        self.new_btn.place(x=20,y=120)
        self.save_btn = Button(self.wn, font='Arial 9 ', text='Save', width=9, height=2, relief=GROOVE,command=self.add_brand)
        self.save_btn.place(x=130, y=120)
        self.delete_btn = Button(self.wn, font='Arial 9 ', text='Delete', width=9, height=2, relief=GROOVE,command=self.delete_brand)
        self.delete_btn.place(x=250, y=120)
        self.update_btn = Button(self.wn, font='Arial 9 ', text='Update', width=9, height=2, relief=GROOVE,command=self.update_brand)
        self.update_btn.place(x=360, y=120)
        self.show_treeview()
    #########FUNCTIONS###########

    def add_brand(self):
        brand_name=self.brand_ent.get()
        remarks=self.remarks_ent.get()
        store=bran.show_specific()
        L=sorted(store)
        stack=self.find(L,brand_name.capitalize())
        if len(brand_name) and len(remarks)>0:
            if stack==True:
                messagebox.showinfo('Info','Brand is already added')
            else:
                if bran.add_brand(brand_name.capitalize(), remarks):
                    messagebox.showinfo('Congrats', 'Brand added')
                    self.show_treeview()

        else:
            messagebox.showerror('Error','Please fill the fields')

    def find(self,L, target):
        start = 0
        end = len(L) - 1
        while start <= end:
            middle = (start + end) // 2
            midpoint = L[middle]
            if midpoint > target:
                end = middle - 1
            elif midpoint < target:
                start = middle + 1
            else:
                return True
    def show_treeview(self):
        brand_tree.delete(*brand_tree.get_children())
        store=bran.show_brand()
        for i in store:
            brand_tree.insert("","end",text=i[0],value=(i[0],i[1],i[2]))
        brand_tree.bind("<Double-1>",self.selected_brand)
    def new_brand(self):
        self.brand_ent.delete(0,'end')
        self.remarks_ent.delete(0,'end')
    def selected_brand(self,event):
        selected=brand_tree.selection()[0]
        selected_brand=brand_tree.item(selected,'values')
        self.index=brand_tree.item(selected,'text')
        self.brand_ent.delete(0,END)
        self.brand_ent.insert(0,selected_brand[1])
        self.remarks_ent.delete(0, END)
        self.remarks_ent.insert(0, selected_brand[2])
    def delete_brand(self):
        if bran.delete_brand(self.index):
            self.show_treeview()
            messagebox.showinfo('Info','Selected Brand is deleted')
            self.index=''

    def update_brand(self):
        name=self.brand_ent.get()
        remarks=self.remarks_ent.get()
        if len(name) and len(remarks)>0:
            if bran.update_brand(self.index,name,remarks):
                messagebox.showinfo('Info','Successfully Updated')
                self.show_treeview()
                self.index=''
        else:
            messagebox.showinfo('Info', 'please fill the fields')

