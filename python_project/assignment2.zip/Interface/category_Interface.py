from tkinter import *
from Files.Category_Files import cat_op
from tkinter import ttk
from tkinter import messagebox
cat=cat_op()
class catg:
    def __init__(self,wn):
        self.wn=wn
        self.wn.geometry('450x450+200+200')
        self.wn.title('Add new category')
        global index
        index=''
        #######LABEL##############
        self.category = Label(self.wn, text='* Category Name',font='Arial 11 bold').place(x=30,y=10)
        self.remarks = Label(self.wn, text='Remarks', font='Arial 11 bold').place(x=30, y=60)
        ######Entry#############
        self.category_ent = Entry(self.wn, font='Arial 17 bold',bg='orange',fg='white')
        self.category_ent.place(x=170, y=10)
        self.remarks_ent = Entry(self.wn, font='Arial 18 bold',bg='orange',fg='white')
        self.remarks_ent.place(x=170, y=60)
        #####TREEVIEW#######
        global cat_tree
        cat_tree=ttk.Treeview(self.wn,columns=('id','Category Name','Remarks'))
        cat_tree.place(x=0,y=170)
        cat_tree['show']='headings'
        cat_tree.column('id',width=90)
        cat_tree.column('Category Name', width=140)
        cat_tree.column('Remarks', width=215)
        cat_tree.heading('id',text='ID')
        cat_tree.heading('Category Name',text='Category Name')
        cat_tree.heading('Remarks',text='Remarks')

        #####BUTTON############
        self.new_btn=Button(self.wn,font='Arial 9 ',text='New',width=9,height=2,relief=GROOVE,command=self.new_category)
        self.new_btn.place(x=20,y=120)
        self.save_btn = Button(self.wn, font='Arial 9 ', text='Save', width=9, height=2, relief=GROOVE,command=self.add_category)
        self.save_btn.place(x=130, y=120)
        self.delete_btn = Button(self.wn, font='Arial 9 ', text='Delete', width=9, height=2, relief=GROOVE,command=self.delete_category)
        self.delete_btn.place(x=250, y=120)
        self.update_btn = Button(self.wn, font='Arial 9 ', text='Update', width=9, height=2, relief=GROOVE,command=self.update_category)
        self.update_btn.place(x=360, y=120)
        self.show_treeview()
    #########FUNCTIONS###########

    def add_category(self):
        cat_name=self.category_ent.get()
        remarks=self.remarks_ent.get()
        stack=cat.show_specific()
        l=sorted((stack))
        print(l)
        print(stack)
        store=self.find(l,cat_name.capitalize())
        print(store)
        if len(cat_name) and len(remarks)>0:
            if store==True:
                messagebox.showinfo('Info','Category is already added')
            else:
                if cat.add_cat(cat_name.capitalize(),remarks):
                    messagebox.showinfo('Congrats','Category added')
                    self.show_treeview()
        else:
            messagebox.showerror('Error','Please fill the fields')

    def find(self, L, target):
        start = 0
        end = len(L) - 1
        while start <= end:
            middle = (start + end) // 2
            midpoint = L[middle]
            if midpoint > target:
                end = middle - 1
            elif midpoint < target:
                start = middle + 1
            else:
                return True
    def show_treeview(self):
        cat_tree.delete(*cat_tree.get_children())
        store=cat.show_category()
        for i in store:
            cat_tree.insert("","end",text=i[0],value=(i[0],i[1],i[2]))
        cat_tree.bind("<Double-1>",self.selected_category)
    def new_category(self):
        self.category_ent.delete(0,'end')
        self.remarks_ent.delete(0,'end')
    def selected_category(self,event):
        selected=cat_tree.selection()[0]
        selected_cat=cat_tree.item(selected,'values')
        self.index=cat_tree.item(selected,'text')
        self.category_ent.delete(0,END)
        self.category_ent.insert(0,selected_cat[1])
        self.remarks_ent.delete(0, END)
        self.remarks_ent.insert(0, selected_cat[2])
    def delete_category(self):
        if cat.delete_cat(self.index):
            self.show_treeview()
            messagebox.showinfo('Info','Selected Category is deleted')
            self.index=''

    def update_category(self):
        name=self.category_ent.get()
        remarks=self.remarks_ent.get()
        if len(name) and len(remarks)>0:
            if cat.update_cat(self.index,name,remarks):
                messagebox.showinfo('Info','Successfully Updated')
                self.show_treeview()
                self.index=''
        else:
            messagebox.showerror('Error', 'Cannot be updated')