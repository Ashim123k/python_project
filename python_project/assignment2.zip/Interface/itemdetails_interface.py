from tkinter import *
from Files.Itemdetails_Files import details
from tkinter import ttk, messagebox
from Files.Category_Files import cat_op
from Files.Brand_File import brand_op

cat = cat_op()
brand = brand_op()
det = details()


class itemdetails:
    def __init__(self, won):
        self.won = won
        self.won.geometry('470x550+200+150')
        self.won.title('Add new Item')
        global index
        global item_tree
        global cat_get
        global brand_get
        index = ''
        self.cat_get = ''
        self.brand_get = ''
        self.selected_details_list = []
        self.all_brand = brand.show_brand()
        self.all_cat = cat.show_category()
        #######LABEL##############
        self.category = Label(self.won, text='* Category Name', font='Arial 11 ').place(x=30, y=10)
        self.Brand = Label(self.won, text='* Brand Name', font='Arial 11 ').place(x=30, y=50)
        self.quantity = Label(self.won, text='*  Quantity', font='Arial 11 ').place(x=30, y=95)
        self.price = Label(self.won, text='* Price', font='Arial 11 ').place(x=30, y=145)
        self.stock = Label(self.won, text='Stock', font='Arial 11 ').place(x=300, y=145)
        self.remarks = Label(self.won, text='Remarks', font='Arial 11 ').place(x=30, y=200)
        self.ml_label = Label(self.won, text='ml', font='Arial 11', fg='blue').place(x=250, y=99)
        ######Entry#############
        self.quantity_ent = Entry(self.won, font='Arial 15 bold', background='orange', foreground='white', width=7)
        self.quantity_ent.place(x=170, y=95)
        self.price_ent = Entry(self.won, font='Arial 15 bold', background='orange', foreground='white', width=7)
        self.price_ent.place(x=170, y=145)
        self.stock_ent = Entry(self.won, font='Arial 15 bold', background='orange', foreground='white', width=7)
        self.stock_ent.place(x=350, y=145)
        self.remarks_ent = Entry(self.won, font='Arial 21 bold', background='orange', foreground='white', width=16)
        self.remarks_ent.place(x=170, y=200)
        ######Combobox#######
        self.category_combobox = ttk.Combobox(self.won, values=self.cat_values_combobox())
        self.category_combobox.place(x=170, y=10)
        self.brand_combobox = ttk.Combobox(self.won, values=self.brand_value_combobox())
        self.brand_combobox.place(x=170, y=50)
        #####BUTTON############
        self.new_btn = Button(self.won, font='Arial 9 ', text='New', width=9, height=2, relief=GROOVE,
                              command=self.new_details)
        self.new_btn.place(x=20, y=240)
        self.save_btn = Button(self.won, font='Arial 9 ', text='Save', width=9, height=2, relief=GROOVE,
                               command=self.add_details)
        self.save_btn.place(x=130, y=240)
        self.delete_btn = Button(self.won, font='Arial 9 ', text='Delete', width=9, height=2, relief=GROOVE,
                                 command=self.delete_details)
        self.delete_btn.place(x=250, y=240)
        self.update_btn = Button(self.won, font='Arial 9 ', text='Update', width=9, height=2, relief=GROOVE,
                                 command=self.update_details)
        self.update_btn.place(x=360, y=240)
        self.frame = Frame(self.won)
        self.frame.place(x=0, y=290, width=470, height=260)
        #####TREEVIEW#######
        self.cat_tree_scrollbar = Scrollbar(self.frame, orient='horizontal')
        self.cat_tree_scrollbar.pack(side=BOTTOM, fill=X)
        self.cat_tree_scrollbarv = Scrollbar(self.frame, orient='vertical')
        self.item_tree = ttk.Treeview(self.frame, selectmode='browse', xscrollcommand=self.cat_tree_scrollbar.set,
                                      yscrollcommand=self.cat_tree_scrollbarv.set)
        self.cat_tree_scrollbarv.pack(side=RIGHT, fill=Y)
        self.item_tree.pack(side=TOP)
        self.cat_tree_scrollbar.config(command=self.item_tree.xview)
        self.cat_tree_scrollbarv.config(command=self.item_tree.yview)
        self.item_tree['column'] = ('1', '2', '3', '4', '5', '6')
        self.item_tree['show'] = 'headings'
        self.item_tree.column('1', width=90, anchor='c')
        self.item_tree.column('2', width=140, anchor='se')
        self.item_tree.column('3', width=140, anchor='se')
        self.item_tree.column('4', width=140, anchor='se')
        self.item_tree.column('5', width=140, anchor='se')
        self.item_tree.column('6', width=215, anchor='se')
        self.item_tree.heading('1', text='Category Name')
        self.item_tree.heading('2', text='Brand Name')
        self.item_tree.heading('3', text='Quantity')
        self.item_tree.heading('4', text='Price')
        self.item_tree.heading('5', text='Stock')
        self.item_tree.heading('6', text='Remarks')
        self.show_treeview()

    #########FUNCTIONS###########
    def on_add_details(self):
        self.cat_get = self.category_combobox.get()
        self.brand_get = self.brand_combobox.get()
        category_index = self.category_combobox.current()
        brand_index = self.brand_combobox.current()
        brands = self.all_brand[brand_index]
        category = self.all_cat[category_index]
        self.selected_details_list.append((brands[0], category[0]))

    def add_details(self):

        self.on_add_details()
        quantity = self.quantity_ent.get()
        price = self.price_ent.get()
        stock = self.stock_ent.get()
        remarks = self.remarks_ent.get()
        stack = det.show_specific()
        stan = [self.selected_details_list, quantity]
        result = self.checking(stack, stan)
        if self.cat_get == '':
            messagebox.showerror("You must select a conversion type", "Error")
            return False
        elif self.brand_get == '':
            messagebox.showerror("You must select a conversion type", "Error")
            return False
        else:
            if len(quantity) and len(price) and len(stock) and len(remarks) > 0:
                if result == False:
                    if quantity.isdigit() and price.isdigit() and stock.isdigit():
                        if det.items_details(quantity, price, stock, remarks, self.selected_details_list):
                            messagebox.showinfo('Info', 'Details added')
                            self.show_treeview()
                            self.selected_details_list.clear()
                        else:
                            messagebox.showerror('Error', 'Something is wrong')
                    else:
                        messagebox.showerror('Error', 'Please enter a valid type')
                else:
                    messagebox.showinfo('Info', 'Item details is available')
            else:
                messagebox.showinfo('Info', 'Please fill the fields')

    def checking(self, L, target):
        count = 0
        for i in L:
            if i[0] == target[0][0][0] and i[1] == target[0][0][1] and i[2] == int(target[1]):
                count += 1

        return count

    def show_treeview(self):
        self.item_tree.delete(*self.item_tree.get_children())
        store = det.join_table()
        for i in store:
            mn = (i[3], 'ml')
            self.item_tree.insert("", "end", text=i[0], values=(i[1], i[2], mn, i[4], i[5], i[6]))
        self.item_tree.bind("<Double-1>", self.selected_category)

    def delete_details(self):
        if det.delete_details(self.index):
            self.show_treeview()
            messagebox.showinfo('Info', 'Selected Category is deleted')
            self.index = ''

    def selected_category(self, event):
        selected = self.item_tree.selection()[0]
        selected_details = self.item_tree.item(selected, 'values')
        self.index = self.item_tree.item(selected, 'text')
        self.nam = ''
        for i in selected_details[2]:
            if i.isdigit():
                self.nam += i
            else:
                break
        print(self.nam)
        self.category_combobox.delete(0, END)
        self.category_combobox.insert(0, selected_details[0])
        self.brand_combobox.delete(0, END)
        self.brand_combobox.insert(0, selected_details[1])
        self.quantity_ent.delete(0, END)
        self.quantity_ent.insert(0, self.nam)
        self.price_ent.delete(0, END)
        self.price_ent.insert(0, selected_details[3])
        self.stock_ent.delete(0, END)
        self.stock_ent.insert(0, selected_details[4])
        self.remarks_ent.delete(0, END)
        self.remarks_ent.insert(0, selected_details[5])

    def new_details(self):
        self.category_combobox.delete(0, 'end')
        self.remarks_ent.delete(0, 'end')
        self.brand_combobox.delete(0, 'end')
        self.stock_ent.delete(0, 'end')
        self.price_ent.delete(0, 'end')
        self.quantity_ent.delete(0, 'end')

    def update_details(self):
        self.on_add_details()
        remarks = self.remarks_ent.get()
        quantity = self.quantity_ent.get()
        price = self.price_ent.get()
        supply = self.stock_ent.get()
        if self.cat_get == '':
            messagebox.showerror("Error", "Select a item from combobox first!!!")

        elif self.brand_get == '':
            messagebox.showerror("Error", "Select a item from combobox first!!!")

        else:
            if len(quantity) and len(price) and len(supply) > 0:
                if quantity.isdigit() and price.isdigit() and supply.isdigit():
                    try:
                        det.update_details(self.index, quantity, price, supply, remarks, self.selected_details_list)
                        messagebox.showinfo('Info', 'Successfully Updated')
                        self.show_treeview()
                        self.index = ''
                    except Exception as e:
                        messagebox.showerror('Error', e.__cause__)
                else:
                    messagebox.showerror('Error', 'Please enter a valid type')
            else:
                messagebox.showerror('Error', 'Please fill the fields')

    def cat_values_combobox(self):
        store = cat.show_category()
        store_list = []
        for i in store:
            store_list.append(i[1])

        return store_list

    def brand_value_combobox(self):
        stack = brand.show_brand()
        store_stack = []
        for i in stack:
            store_stack.append(i[1])
        return store_stack



