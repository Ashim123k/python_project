from __future__ import print_function
from tkinter import *
from tkinter import ttk, messagebox
from Files.supplyinandout_Files import supply_out
from Files.Itemdetails_Files import details
from Files.database_query import MyDb


det = details()
sup = supply_out()
my = MyDb()



class supply_out:
    def __init__(self, wn):
        self.wn = wn
        self.wn.geometry('470x550+200+150')
        self.wn.title('Supply out')
        global index
        global item_tree
        global date_ent
        global point
        global total
        self.total=''
        index = ''
        self.item_detail = det.show_item()
        self.selected_details_list = []
        self.point=0
        #######LABEL##############
        self.item_name = Label(self.wn, text='* Item Name', font='Arial 11 ').place(x=30, y=50)
        self.supply = Label(self.wn, text='* Supply Out', font='Arial 11 ').place(x=30, y=110)
        self.amount = Label(self.wn, text='*  Amount', font='Arial 11 ').place(x=270, y=110)
        self.remarks = Label(self.wn, text='Remarks', font='Arial 11 ').place(x=30, y=180)
        self.lb = Label(self.wn, text='Date: (DD      /MM      /YYYY)')
        self.lb.place(x=310, y=0)
        self.stock_lb = Label(self.wn, text='Current supply:', fg='blue').place(x=130, y=85)
        ######Entry#############
        self.supply_ent = Entry(self.wn, font='Arial 15 bold', background='orange', foreground='white', width=7)
        self.supply_ent.bind('<KeyRelease>', lambda e: self.GetAmount())
        self.supply_ent.place(x=140, y=110)
        self.amount_ent = Entry(self.wn, font='Arial 15 bold', width=7, state="readonly",
                                readonlybackground='orange')
        self.amount_ent.place(x=355, y=110)
        self.remarks_ent = Text(self.wn, font='Arial 15 bold', background='orange', foreground='white', width=27,
                                height=2)
        self.remarks_ent.place(x=140, y=173)

        #####TrY ENTRYBOX#######
        self.ent_1 = Entry(self.wn, font='15,Arial', width=4)
        self.lb1 = Label(self.wn, text='/')
        self.ent_2 = Entry(self.wn, width=4, font='15,Arial')
        self.lb2 = Label(self.wn, text='/')
        self.ent_3 = Entry(self.wn, width=6, font='15,Arial')

        self.ent_1.place(x=337, y=15)
        self.lb1.place(x=370, y=15)
        self.ent_2.place(x=382, y=15)
        self.lb2.place(x=414, y=15)
        self.ent_3.place(x=427, y=15)

        self.date_ent = [self.ent_1, self.ent_2, self.ent_3]

        self.ent_1.bind('<KeyRelease>', lambda e: self._check(0, 2))
        self.ent_2.bind('<KeyRelease>', lambda e: self._check(1, 2))
        self.ent_3.bind('<KeyRelease>', lambda e: self._check(2, 4))
        ######Combobox#######

        self.item_combobox = ttk.Combobox(self.wn, font='20', width=30, values=self.item_combobox())
        self.item_combobox.bind('<<ComboboxSelected>>', lambda e: self.GetAmount())
        self.item_combobox.place(x=140, y=50)

        #####BUTTON############
        self.new_btn = Button(self.wn, font='Arial 9 ', text='New', width=9, height=2, relief=GROOVE,command=self.new_details)
        self.new_btn.place(x=20, y=240)
        self.save_btn = Button(self.wn, font='Arial 9 ', text='Save', width=9, height=2, relief=GROOVE,
                               command=self.add_supply)
        self.save_btn.place(x=130, y=240)
        self.delete_btn = Button(self.wn, font='Arial 9 ', text='Delete', width=9, height=2, relief=GROOVE,command=self.delete_details)
        self.delete_btn.place(x=250, y=240)
        self.update_btn = Button(self.wn, font='Arial 9 ', text='Update', width=9, height=2, relief=GROOVE,command=self.update_details)
        self.update_btn.place(x=360, y=240)
        self.frame = Frame(self.wn)
        self.frame.place(x=0, y=290, width=470, height=260)
        #####TREEVIEW#######
        self.cat_tree_scrollbar = Scrollbar(self.frame, orient='horizontal')
        self.cat_tree_scrollbar.pack(side=BOTTOM, fill=X)
        self.cat_tree_scrollbarv = Scrollbar(self.frame, orient='vertical')
        self.supply_tree = ttk.Treeview(self.frame, selectmode='browse', xscrollcommand=self.cat_tree_scrollbar.set,
                                        yscrollcommand=self.cat_tree_scrollbarv.set)
        self.cat_tree_scrollbarv.pack(side=RIGHT, fill=Y)
        self.supply_tree.pack(side=TOP)
        self.cat_tree_scrollbar.config(command=self.supply_tree.xview)
        self.cat_tree_scrollbarv.config(command=self.supply_tree.yview)
        self.supply_tree['column'] = ('1', '2', '3', '4', '5')
        self.supply_tree['show'] = 'headings'
        self.supply_tree.column('1', width=140, anchor='c')
        self.supply_tree.column('2', width=140, anchor='se')
        self.supply_tree.column('3', width=140, anchor='se')
        self.supply_tree.column('4', width=140, anchor='se')
        self.supply_tree.column('5', width=140, anchor='se')
        self.supply_tree.heading('1', text='Item Name')
        self.supply_tree.heading('2', text='In Date')
        self.supply_tree.heading('3', text='Supply Out')
        self.supply_tree.heading('4', text='Amount')
        self.supply_tree.heading('5', text='Remarks')
        self.show_treeview()

    #########FUNCTIONS###########
    def on_add_details(self):
        self.total=self.item_combobox.get()
        item_index = self.item_combobox.current()
        items = self.item_detail[item_index]
        self.point=items[0]
        self.selected_details_list.append(items)

    def add_supply(self):
        self.on_add_details()
        date = self.ent_1.get()
        month = self.ent_2.get()
        year = self.ent_3.get()
        amount = self.amount_ent.get()
        stock_in = self.supply_ent.get()
        remarks = self.remarks_ent.get('1.0', END)
        if self.total=='':
            messagebox.showerror("Error","Select a item from combobox first!!!")
        elif len(date and month)<2 and len(year)<4:
            messagebox.showinfo('Info', 'Enter two digit number')
        elif int(date)>=33:
            messagebox.showinfo('Info','Date must be less than 32')
        elif int(month)>=13:
            messagebox.showinfo('Info','Month must be less than or equal to 12')
        else:
            if len(date and month and year)>0:
                if date.isdigit() and month.isdigit() and year.isdigit():
                    if sup.supply_out(amount, date, month, year, stock_in, remarks, self.selected_details_list,self.point):
                        messagebox.showinfo('Info', 'Details added')
                        self.show_treeview()

                    else:
                        messagebox.showerror('Error', 'Something is wrong')
                else:
                    messagebox.showerror('Error','Please enter valid type')
            else:
                messagebox.showerror('Error','Please all fields')
        self.selected_details_list.clear()

    def show_treeview(self):
        self.supply_tree.delete(*self.supply_tree.get_children())
        store = sup.join_table()

        for i in store:
            self.date = i[6], '/', i[7], '/', i[8]
            self.supply_tree.insert("", "end", text=i[13], values=(i[9], self.date, i[3], i[4], i[5]))
        self.supply_tree.bind("<Double-1>", self.selected_category)

    def delete_details(self):
        if sup.delete_details(self.index):
            self.show_treeview()
            messagebox.showinfo('Info', 'Selected Category is deleted')
            self.index = ''

    def selected_category(self, event):
        selected = self.supply_tree.selection()[0]
        selected_details = self.supply_tree.item(selected, 'values')
        first_ent=(selected_details[1][0]+selected_details[1][1])
        second_ent=selected_details[1][5]+selected_details[1][6]
        third_ent=selected_details[1][10]+selected_details[1][11]+selected_details[1][12]+selected_details[1][12]
        self.index = self.supply_tree.item(selected, 'text')
        self.item_combobox.delete(0, END)
        self.item_combobox.insert(0, selected_details[0])
        self.supply_ent.delete(0, END)
        self.supply_ent.insert(0, selected_details[2])
        self.amount_ent.configure(state='normal', background='orange', foreground='white')
        self.amount_ent.delete(0, END)
        self.amount_ent.insert(0, selected_details[3])
        self.amount_ent.configure(state='readonly', background='orange', foreground='white')
        self.remarks_ent.delete(1.0, END)
        self.remarks_ent.insert(1.0, selected_details[4])
        self.ent_1.delete(0, END)
        self.ent_1.insert(0, first_ent)
        self.ent_2.delete(0, END)
        self.ent_2.insert(0, second_ent)
        self.ent_3.delete(0, END)
        self.ent_3.insert(0, third_ent)

    def new_details(self):
        self.item_combobox.delete(0,'end')
        self.remarks_ent.delete(1.0,'end')
        self.amount_ent.configure(state='normal', background='orange', foreground='white')
        self.amount_ent.delete(0, 'end')
        self.amount_ent.configure(state='readonly', background='orange', foreground='white')
        self.supply_ent.delete(0, 'end')
        self.ent_1.delete(0, 'end')
        self.ent_2.delete(0, 'end')
        self.ent_3.delete(0,'end')

    def update_details(self):
        self.on_add_details()
        remarks=self.remarks_ent.get(1.0,'end')
        amount = self.amount_ent.get()
        supply_in = self.supply_ent.get()
        date = self.ent_1.get()
        month=self.ent_2.get()
        year=self.ent_3.get()
        if sup.update_details(self.index,supply_in,amount,remarks,date,month,year,self.selected_details_list):
            messagebox.showinfo('Info','Successfully Updated')
            self.show_treeview()
            self.index=''
        else:
            messagebox.showerror('Error','Cannot be updated')

    def item_combobox(self):
        store = sup.join_tables()
        store_list = []
        for i in store:
            store_list.append((i[3],i[4],i[0],'ml'))

        return store_list

    def _backspace(self, entry):
        cont = entry.get()
        entry.delete(0, END)
        entry.insert(0, cont[:-1])

    def _check(self, index, size):
        entry = self.date_ent[index]
        next_index = index + 1
        next_entry = self.date_ent[next_index] if next_index < len(self.date_ent) else None
        data = entry.get()

        if len(data) > size or not data.isdigit():
            self._backspace(entry)
        if len(data) >= size and next_entry:
            next_entry.focus()

    def get(self):
        return [e.get() for e in self.date_ent]

    def GetAmount(self):

        try:
            item_index = self.item_combobox.current()
            items = self.item_detail[item_index]
            qry = "SELECT Price FROM item_details WHERE id = %s "
            values = (items[0],)
            store = my.show_data_p(qry, values)
            if (self.supply_ent.get() != ""):
                totalmount = float(self.supply_ent.get()) * store[0][0]
                self.amount_ent.delete(0, 'end')
                self.amount_ent.configure(state='normal', background='orange', foreground='white')
                self.amount_ent.insert(0, totalmount)

            else:
                self.amount_ent.configure(state='normal', background='orange', foreground='white')
                self.amount_ent.delete(0, 'end')
        except Exception as e:
            messagebox.showerror('error', e.__class__)
        finally:
            self.amount_ent.configure(state='readonly', background='orange', foreground='white')

