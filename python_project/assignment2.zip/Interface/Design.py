from tkinter import *
from tkinter import messagebox
import time
from PIL import ImageTk, Image, ImageSequence
from tkinter import ttk
from Files.supplyinandout_Files import supply
from Files.product_file import search
from Files.Itemdetails_Files import details
from Files.staff_file import staff
from Files.login_file import Log_in

stall = staff()
det = details()
find = search()
sup = supply()
log = Log_in()

count = 0
text = ''


class App(Tk):
    def __init__(self):
        Tk.__init__(self)
        # Setup Frame
        width = self.winfo_screenwidth()
        height = self.winfo_screenheight()
        self.geometry('%dx%d+0+0' % (width, height))
        self.attributes('-toolwindow', True)

        self._frame = None
        self.switch_frame(Login)

    def switch_frame(self, frame_class):
        new_frame = frame_class(self)
        if self._frame is not None:
            self._frame.destroy()
        self._frame = new_frame
        self._frame.pack()


class Login(Frame):
    def __init__(self, window):
        Frame.__init__(self, window)
        self.window = window
        self.window.title('Login Form')
        global tt
        self.tt = ''
        self.canvas = Canvas(self.window, width=2000, height=790)
        self.canvas.place(x=0, y=0)

        self.sequence = [ImageTk.PhotoImage(img)
                         for img in ImageSequence.Iterator(
                Image.open(
                    r'Z:\Algorithm\Final_Assignment\Interface\liquorstore.gif'))]
        self.image = self.canvas.create_image(760, 400, image=self.sequence[0])
        self.animate(1)
        self.clock = Label(self.window, font=('calibri', 30, 'bold'), background='purple', foreground='white')
        self.clock.place(x=1283, y=5)
        self.login_frame = Frame(self.window, bg='#00FFFF')
        self.login_frame.place(x=575, y=345)

        #######LABEL#######
        self.login_lb = Label(self.login_frame, text='Log in', font='Arial 20 bold').grid(row=0, columnspan=3,
                                                                                          pady=10, padx=15)
        self.user_icon = PhotoImage(file='user1.png')
        self.pasww_icon = PhotoImage(file='password1.png')
        self.username = Label(self.login_frame, text='Username', image=self.user_icon, compound=LEFT,
                              font='Porcelain  13 bold')
        self.username.grid(row=2, column=0, pady=15, padx=10)
        self.password = Label(self.login_frame, text='Password', font='Arial 13 bold', image=self.pasww_icon,
                              compound=LEFT)
        self.password.grid(row=3, column=0, pady=15, padx=10)
        #######ENTRY########
        self.username_ent = Entry(self.login_frame, font='Arial 15 bold')
        self.username_ent.grid(row=2, column=2, pady=15, padx=15)
        self.password_ent = Entry(self.login_frame, font='Arial 15 bold', show='*')
        self.password_ent.grid(row=3, column=2, pady=15, padx=15)
        ########BUTTONS#####
        self.login_check = Checkbutton(self.login_frame, text='Show password', onvalue=True, offvalue=False,
                                       command=self.show_psswrd, bg='white', fg='red')
        self.login_check.var = BooleanVar(value=False)
        self.login_check.place(x=10, y=170)
        self.login_check['variable'] = self.login_check.var
        self.but = Button(self.login_frame, text='login', font='Arial 10 bold', command=self.log_in)
        self.but.grid(row=4, column=2, pady=10, padx=10)
        self.time()

    def animate(self, counter):
        self.canvas.itemconfig(self.image, image=self.sequence[counter])
        self.window.after(100, lambda: self.animate((counter + 1) % len(self.sequence)))

    def show_psswrd(self):
        if self.login_check.var.get():
            self.password_ent['show'] = ''
        else:
            self.password_ent['show'] = '*'

    def time(self):
        string = time.strftime('%H:%M:%S')
        datestr = time.strftime('%d/%m/%y')
        self.clock.config(text='Date:' + datestr + '\n' 'Time:' + string)
        self.clock.after(200, self.time)

    def log_in(self):
        name = self.username_ent.get()
        passw = self.password_ent.get()
        store = log.login(name, passw)

        self.tt = f'Welcome {name}'
        if len(name and passw) > 0:
            if store == 1:
                self.window.switch_frame(admin_page)
                self.sliderLabel = Label(self.window, text=self.tt, font='Arial 20 bold', relief=RIDGE, borderwidth=0,
                                         highlightthickness=0)
                self.sliderLabel.pack(anchor='n')
                self.IntroLabelTick()


            else:
                messagebox.showinfo('Info', 'Username or password is wrong')
        else:
            messagebox.showinfo('Info', 'Fill the fields')

    def IntroLabelTick(self):
        global count, text
        if (count >= len(self.tt)):
            count = -1
            text = " "
            self.sliderLabel.config(text=text)
        else:
            text = text + self.tt[count]
            self.sliderLabel.config(text=text)
        count += 1
        self.sliderLabel.after(300, self.IntroLabelTick)
        self.login_frame.destroy()


class admin_page(Frame):
    def __init__(self, window):
        Frame.__init__(self, window)
        self.window = window
        self.window.title('Admin Page')
        self.canvass = Canvas(self.window, width=1530, height=790)
        self.canvass.place(x=0, y=0)
        self.sequence = [ImageTk.PhotoImage(img)
                         for img in ImageSequence.Iterator(
                Image.open(
                    r'Z:\Algorithm\Final_Assignment\Interface\allooo.gif'))]
        self.image = self.canvass.create_image(760, 400, image=self.sequence[0])
        self.animate(1)
        self.clock = Label(self.window, font=('calibri', 20, 'bold'), background='#a391c1', foreground='white')
        self.clock.place(x=1350, y=10)

        self.admin_frame = Frame(self.window, bg='black')
        self.admin_frame.place(x=10, y=10)

        self.entry = Button(self.admin_frame, text='Entries', font='Arial 20 bold', fg='black',
                            bg='white', width=10, command=self.frames)
        self.entry.grid(row=0, column=1, pady=10)
        self.history = Button(self.admin_frame, text='sales', font='Arial 20 bold', fg='black',
                              bg='white', width=10, command=self.fram)
        self.history.grid(row=1, column=1, pady=10)
        self.products = Button(self.admin_frame, text='Products', font='Arial 20 bold', fg='black',
                               bg='white', width=10, command=self.product)
        self.products.grid(row=2, column=1, pady=10)
        self.add = Button(self.admin_frame, text='Add Staffs', font='Arial 20 bold', fg='black',
                          bg='white', width=10, command=self.framm)
        self.add.grid(row=3, column=1, pady=10)

        ###### menu#######menu########menu#####

        self.my_menu = Menu(self.admin_frame, tearoff=True)
        self.my_menu.add_command(label='Quit', command=self.quit_btn)
        self.master.option_add('*tearOff', False)
        self.window.config(menu=self.my_menu)
        # self.back_btn = Menu(self.my_menu, tearoff=0)
        # self.back_btn.add_command( command=self.back_button,image=self.bag)
        ITEM = Menu(self.my_menu)
        self.my_menu.add_cascade(label="ITEM", menu=ITEM)
        ITEM.add_cascade(label="Category", command=self.category)
        ITEM.add_cascade(label="Brand", command=self.brands)
        ITEM.add_cascade(label="Add Item", command=self.items_details)
        stock_menu = Menu(self.my_menu)
        self.my_menu.add_cascade(label="SUPPLY", menu=stock_menu)
        stock_menu.add_cascade(label="Supply in", command=self.supply_in)
        stock_menu.add_cascade(label=" Supply out", command=self.supply_out)
        self.time()

    def animate(self, counter):
        self.canvass.itemconfig(self.image, image=self.sequence[counter])
        self.window.after(100, lambda: self.animate((counter + 1) % len(self.sequence)))

    def time(self):
        string = time.strftime('%H:%M:%S')
        datestr = time.strftime('%d/%m/%y')
        self.clock.config(text='Date:' + datestr + '\n' 'Time:' + string)
        self.clock.after(200, self.time)

    def product(self):
        self.window.switch_frame(products)
        self.admin_frame.destroy()

    def framm(self):
        self.window.switch_frame(staffs)
        self.admin_frame.destroy()

    def frames(self):
        self.window.switch_frame(entry)
        self.admin_frame.destroy()

    def fram(self):
        self.window.switch_frame(sale)
        self.admin_frame.destroy()

    def quit_btn(self):
        ans = messagebox.askyesno('Note', 'Do you really wanna Quit')
        if ans == YES:
            self.window.destroy()

    def category(self):
        from Interface import category_Interface
        wn = Toplevel()
        call = category_Interface.catg(wn)
        wn.mainloop()

    def brands(self):
        from Interface import Brand_interface
        wn = Toplevel()
        call = Brand_interface.Brand(wn)
        wn.mainloop()

    def items_details(self):
        from Interface.itemdetails_interface import itemdetails
        won = Toplevel()
        call = itemdetails(won)
        won.mainloop()

    def supply_in(self):
        from Interface.supply_in_interface import supplyin
        window = Toplevel()
        supplyin(window)
        window.mainloop()

    def supply_out(self):
        from Interface.supply_out_interface import supply_out
        wn = Toplevel()
        supply_out(wn)
        wn.mainloop()


class entry(Frame):
    def __init__(self, window):
        Frame.__init__(self, window)
        self.wn = window
        self.wn.title('Entry Form')
        self.canvas = Canvas(self.wn, width=2000, height=790)
        self.canvas.place(x=0, y=0)
        self.sequence = [ImageTk.PhotoImage(img)
                         for img in ImageSequence.Iterator(
                Image.open(
                    r'Z:\Algorithm\Final_Assignment\Interface\vodkaaaaaa.gif'))]
        self.image = self.canvas.create_image(760, 370, image=self.sequence[0])
        self.animate(1)

        self.frame2 = Frame(self.wn, bg='white')
        self.frame2.place(x=50, y=100)
        self.lb = Label(self.frame2, text='Brand Name', font='Arial 15 bold')
        self.lb.grid(row=0, column=1, pady=5)
        self.search_name = Entry(self.frame2, font='Arial 15 bold')
        self.search_name.grid(row=1, column=1, pady=5)
        self.search_btn = Button(self.frame2, text='Search', font='Arial 10 bold', width=10,
                                 command=self.search_entry)
        self.search_btn.grid(row=2, column=1, pady=5)

        # -----------Menuuu-------Menuuuu
        self.my_menu = Menu(self.frame2, tearoff=True)
        self.my_menu.add_command(label='Back', command=self.back_btn)
        self.master.option_add('*tearOff', False)
        self.wn.config(menu=self.my_menu)

    def showw(self):
        self.frame1 = Frame(self.wn, bg='black')
        self.frame1.place(x=500, y=300)
        self.ent_tree = ttk.Treeview(self.frame1, selectmode='browse')
        self.ent_tree.grid(row=0, column=0)
        self.ent_tree['column'] = ('1', '2', '3', '4')
        self.ent_tree['show'] = 'headings'
        self.ent_tree.column('1', width=140, anchor='c')
        self.ent_tree.column('2', width=140, anchor='se')
        self.ent_tree.column('3', width=140, anchor='se')
        self.ent_tree.column('4', width=140, anchor='se')
        self.ent_tree.heading('1', text='Item Name')
        self.ent_tree.heading('2', text='Entries')
        self.ent_tree.heading('3', text='Date')
        self.ent_tree.heading('4', text='Amount')
        self.showentr_tree()

    def animate(self, counter):
        self.canvas.itemconfig(self.image, image=self.sequence[counter])
        self.wn.after(100, lambda: self.animate((counter + 1) % len(self.sequence)))

    def showentr_tree(self):
        from Files.supplyinandout_Files import supply
        supp = supply()
        store = supp.join_table()

        for i in store:
            self.date = i[6], '/', i[7], '/', i[8]
            self.ent_tree.insert("", "end", text=i[13], values=(i[9], i[3], self.date, i[4]))

    def back_btn(self):
        self.wn.switch_frame(admin_page)
        self.frame2.destroy()

    def search_entry(self):
        ent_name = self.search_name.get()
        from Files.ent_file import search
        sear = search()
        store = sear.supply_search(ent_name)
        self.showw()
        self.ent_tree.delete(*self.ent_tree.get_children())
        for i in store:
            self.date = i[6], '/', i[7], '/', i[8]
            self.ent_tree.insert("", "end", text=i[0], values=(i[9], i[3], self.date, i[4]))


class sale(Frame):
    def __init__(self, window):
        Frame.__init__(self, window)
        self.window = window
        self.window.title('Sale Form')

        self.canvas = Canvas(self.window, width=2000, height=790)
        self.canvas.place(x=0, y=0)
        self.sequence = [ImageTk.PhotoImage(img)
                         for img in ImageSequence.Iterator(
                Image.open(
                    r'Z:\Algorithm\Final_Assignment\Interface\vodkaaaaaa.gif'))]
        self.image = self.canvas.create_image(760, 370, image=self.sequence[0])
        self.animate(1)
        self.frame3 = Frame(self.window, bg='white')
        self.frame3.place(x=50, y=100)
        self.lb = Label(self.frame3, text='Brand Name', font='Arial 20 bold')
        self.lb.grid(row=0, column=2)
        self.search_name = Entry(self.frame3, font='Arial 20 bold')
        self.search_name.grid(row=1, column=2)
        self.search_btn = Button(self.frame3, text='Search', font='Arial 10 bold', width=10,
                                 command=self.showw).grid(row=2, column=2)

        # -------Menuuuu-----Menuuuuu
        self.my_menu = Menu(self.frame3, tearoff=True)
        self.my_menu.add_command(label='Back', command=self.back_boton)
        self.master.option_add('*tearOff', False)
        self.window.config(menu=self.my_menu)

    def showw(self):
        self.frame = Frame(self.window, bg='black').place(x=500, y=300)
        self.sale_tree = ttk.Treeview(self.frame, selectmode='browse')
        self.sale_tree.place(x=500, y=250)
        self.sale_tree['column'] = ('1', '2', '3', '4')
        self.sale_tree['show'] = 'headings'
        self.sale_tree.column('1', width=140, anchor='c')
        self.sale_tree.column('2', width=140, anchor='se')
        self.sale_tree.column('3', width=140, anchor='se')
        self.sale_tree.column('4', width=140, anchor='se')
        self.sale_tree.heading('1', text='Item Name')
        self.sale_tree.heading('2', text='Entries')
        self.sale_tree.heading('3', text='Date')
        self.sale_tree.heading('4', text='Amount')
        self.showsale_tree()

    def animate(self, counter):
        self.canvas.itemconfig(self.image, image=self.sequence[counter])
        self.window.after(100, lambda: self.animate((counter + 1) % len(self.sequence)))

    def showsale_tree(self):
        from Files.supplyinandout_Files import supply_out
        supp = supply_out()
        store = supp.join_table()

        for i in store:
            self.date = i[6], '/', i[7], '/', i[8]
            self.sale_tree.insert("", "end", text=i[13], values=(i[9], i[3], self.date, i[4]))

    def back_boton(self):
        self.window.switch_frame(admin_page)
        self.frame3.destroy()

    def search_sale(self):
        ent_name = self.search_name.get()
        from Files.ent_file import search
        sear = search()
        store = sear.sale_search(ent_name)
        self.sale_tree.delete(*self.sale_tree.get_children())
        for i in store:
            self.date = i[6], '/', i[7], '/', i[8]
            self.sale_tree.insert("", "end", text=i[0], values=(i[9], i[3], self.date, i[4]))


co = 0
txt = ''


class products(Frame):
    def __init__(self, window):
        Frame.__init__(self, window)
        self.window = window
        self.window.title('Product Page')

        self.canvas = Canvas(self.window, width=2000, height=790)
        self.canvas.place(x=0, y=0)
        self.sequence = [ImageTk.PhotoImage(img)
                         for img in ImageSequence.Iterator(
                Image.open(
                    r'Z:\Algorithm\Final_Assignment\Interface\vodkaaaaaa.gif'))]
        self.image = self.canvas.create_image(760, 370, image=self.sequence[0])
        self.animate(1)
        global ite
        global catee
        global pric
        global rem
        global stoc
        global ss
        ss = "Double Tap For Details"

        self.ite = StringVar()
        self.catee = StringVar()
        self.pric = StringVar()
        self.rem = StringVar()
        self.stoc = StringVar()
        self.ite.set('')
        self.catee.set('')
        self.pric.set('')
        self.stoc.set('')
        self.rem.set('')

        # ----------LABEL-------LABEL-----------#
        self.frame4 = Frame(self.window, bg='black')
        self.frame4.place(x=150, y=100)
        self.name = Label(self.frame4, text='Category Name', font='Arial 20 bold').grid(row=0, column=1)
        self.name_ent = Entry(self.frame4, font='Arial 20 bold')
        self.name_ent.grid(row=1, column=1)
        self.search_btn = Button(self.frame4, text='Search', font='Arial 12 bold', command=self.search_name)
        self.search_btn.grid(row=2, column=1)

        self.frame5 = Frame(self.window, bg='black')
        self.frame5.place(x=10, y=390)
        self.sliderLabel = Label(self.frame5, text=ss, font='Arial 20 bold', relief=RIDGE, borderwidth=0,
                                 highlightthickness=0)
        self.sliderLabel.grid(row=3, column=1)
        self.IntroLabelTick()

        self.product_tree = ttk.Treeview(self.frame5, selectmode='browse'
                                         )
        self.product_tree.grid(row=5, column=1)
        self.product_tree['column'] = ('1', '2')
        self.product_tree['show'] = 'headings'
        self.product_tree.column('1', width=300, anchor='c')
        self.product_tree.column('2', width=300, anchor='c')

        self.product_tree.heading('1', text='Item Name')
        self.product_tree.heading('2', text='Category')

        self.my_menu = Menu(self.frame4, tearoff=True)
        self.my_menu.add_command(label='Back', command=self.back_butn)
        self.master.option_add('*tearOff', False)
        self.window.config(menu=self.my_menu)

        self.showproduct_tree()

    def animate(self, counter):
        self.canvas.itemconfig(self.image, image=self.sequence[counter])
        self.window.after(100, lambda: self.animate((counter + 1) % len(self.sequence)))

    def IntroLabelTick(self):
        global co, txt
        if (co >= len(ss)):
            co = -1
            txt = ''
            self.sliderLabel.config(text=txt)
        else:
            txt = txt + ss[co]
            self.sliderLabel.config(text=txt)
        co += 1
        self.sliderLabel.after(150, self.IntroLabelTick)

    def showproduct_tree(self):
        self.product_tree.delete(*self.product_tree.get_children())
        store = det.join_table()
        for i in store:
            item_name = i[2], '-', i[3], 'ml'
            self.product_tree.insert("", "end", text=i[0], values=(item_name, i[1]))
        self.product_tree.bind("<Double-1>", self.selected_category)

    def selected_category(self, event):
        selected = self.product_tree.selection()[0]
        selected_details = self.product_tree.item(selected, 'values')
        self.index = self.product_tree.item(selected, 'text')
        self.frame = Frame(self.frame4, bg='black').place(x=700, y=0)
        self.lb = Label(self.frame, text='Item Details', font='Arial 35 bold').place(x=800, y=50)
        self.Item_lb = Label(self.frame, text='Item Name :', font='Arial 20 bold').place(x=850, y=120)
        self.category = Label(self.frame, text='Category :', font='Arial 20 bold').place(x=850, y=170)
        self.Price_lb = Label(self.frame, text='Price :', font='Arial 19 bold').place(x=850, y=220)
        self.stock_lb = Label(self.frame, text='Stock', font='Arial 20 bold').place(x=850, y=270)

        self.remarks = Label(self.frame, text='Other remarks :', font='Arial 19 bold').place(x=850, y=320)
        result = find.item_detail(self.index)
        self.Item_lb_data = Label(self.frame, textvariable=self.ite, font='Arial 20 bold').place(
            x=1100, y=120)
        self.cat_lb = Label(self.frame, textvariable=self.catee, font='Arial 20 bold').place(x=1100, y=170)
        self.price_lb = Label(self.frame, textvariable=self.pric, font='Arial 20 bold').place(x=1100, y=220)
        self.remarks_lb = Label(self.frame, textvariable=self.rem,
                                font='Arial 20 bold').place(x=1100, y=320)
        self.stock_lb_ent = Label(self.frame, textvariable=self.stoc, font='Arial 20 bold').place(x=1100,
                                                                                                  y=270)
        self.ite.set(result[0][1])
        self.catee.set(result[0][0])
        self.pric.set(result[0][4])
        self.rem.set(result[0][5] + ',' + result[0][6] + ',' + result[0][7])
        if result[0][3] == 1:
            self.stoc.set(str(result[0][3]) + 'box')

        elif result[0][3] > 1:
            self.stoc.set(str(result[0][3]) + 'boxes')

        else:
            self.stoc.set('Stock Unavailable')

    def back_butn(self):
        self.window.switch_frame(admin_page)
        self.frame4.destroy()

    def search_name(self):
        name = self.name_ent.get()
        det = find.search_products(name)
        self.product_tree.delete(*self.product_tree.get_children())
        for i in det:
            item_name = i[1], '-', i[2], 'ml'
            self.product_tree.insert("", "end", text=i[0], values=(item_name, i[0]))


class staffs(Frame):
    def __init__(self, window):
        Frame.__init__(self, window)
        self.window = window
        self.window.title('Staffs')

        self.canvas = Canvas(self.window, width=2000, height=790)
        self.canvas.place(x=0, y=0)
        self.sequence = [ImageTk.PhotoImage(img)
                         for img in ImageSequence.Iterator(
                Image.open(
                    r'Z:\Algorithm\Final_Assignment\Interface\vodkaaaaaa.gif'))]
        self.image = self.canvas.create_image(760, 400, image=self.sequence[0])
        self.animate(1)

        self.lb = Label(self.window, text="Liqour       \n \ \n         Staffs", font='Arial 26 bold').place(x=700,
                                                                                                             y=52)
        self.lb = PhotoImage(file='empl.png')
        self.ll = Label(self.window, image=self.lb)
        self.ll.place(x=550, y=50)
        self.frame4 = Frame(self.window, bg='black')
        self.frame4.place(x=470, y=190)

        # ----------LABEL-------LABEL-----------#
        self.name = Label(self.frame4, text='Staff Name', font='Arial 20 bold').grid(row=0, column=0, padx=10)
        self.password = Label(self.frame4, text='Password', font='Arial 20 bold').grid(row=1, column=0, pady=10,
                                                                                       padx=10)
        self.age = Label(self.frame4, text='Age', font='Arial 20 bold').grid(row=2, column=0, pady=10, padx=10)
        self.address = Label(self.frame4, text='Location', font='Arial 20 bold').grid(row=3, column=0, pady=10, padx=10)
        self.sex = Label(self.frame4, text='Gender', font='Arial 20 bold').grid(row=4, column=0, pady=10, padx=10)
        self.email = Label(self.frame4, text='Email', font='Arial 20 bold').grid(row=5, column=0, pady=10, padx=10)
        self.phone = Label(self.frame4, text='Contact no.', font='Arial 20 bold').grid(row=6, column=0, pady=10,
                                                                                       padx=10)

        # ----------ENTRY-------ENTRY----------#
        self.name_ent = Entry(self.frame4, font='Arial 20 bold')
        self.name_ent.grid(row=0, column=1, pady=10, padx=10)
        self.password_ent = Entry(self.frame4, font='Arial 20 bold')
        self.password_ent.grid(row=1, column=1, pady=10, padx=10)
        self.age_spin = Spinbox(self.frame4, font='Arial 19 bold', from_=18, to=70)
        self.age_spin.grid(row=2, column=1, pady=10, padx=10)

        self.address_ent = Entry(self.frame4, font='Arial 20 bold')
        self.address_ent.grid(row=3, column=1, pady=10, padx=10)

        self.category_combobox = ttk.Combobox(self.frame4, font='Arial 19 bold', values=('Male', 'Female', 'Others'))
        self.category_combobox.grid(row=4, column=1, pady=10, padx=10)
        self.email_ent = Entry(self.frame4, font='Arial 20 bold')
        self.email_ent.grid(row=5, column=1, pady=10, padx=10)
        self.phone_ent = Entry(self.frame4, font='Arial 20 bold')
        self.phone_ent.grid(row=6, column=1, pady=10, padx=10)
        # ---------Buttons-------Buttons-------#
        self.fra = Frame(self.window, bg='black')
        self.fra.place(x=550, y=600)
        self.add = Button(self.fra, text='Add Staffs', font='Arial 15 bold', fg='black',
                          bg='white', width=10, command=self.add_staffs)
        self.add.grid(row=0, column=1, pady=10, padx=10)

        self.new = Button(self.fra, text='New Staffs', font='Arial 15 bold', fg='black',
                          bg='white', width=10, command=self.new_btn)
        self.new.grid(row=0, column=3, pady=10, padx=10)

        ###### menu#######menu########menu#####
        self.my_menu = Menu(self.frame4, tearoff=True)
        self.my_menu.add_command(label='Back', command=self.back_butn)
        self.master.option_add('*tearOff', False)
        self.window.config(menu=self.my_menu)
        ITEM = Menu(self.my_menu)
        self.my_menu.add_cascade(label="Staffs", menu=ITEM)
        ITEM.add_cascade(label="Edit Staffs", command=self.edit_frame)
        ITEM.add_cascade(label="Search Staffs", command=self.search_frame)

    def animate(self, counter):
        self.canvas.itemconfig(self.image, image=self.sequence[counter])
        self.window.after(200, lambda: self.animate((counter + 1) % len(self.sequence)))

    def search_frame(self):
        self.window.switch_frame(search_staffs)
        self.frame4.destroy()

    def edit_frame(self):
        self.window.switch_frame(edit_staffs)
        self.frame4.destroy()

    def new_btn(self):
        self.name_ent.delete(0, END)
        self.password_ent.delete(0, END)
        self.age_spin.delete(0, END)
        self.category_combobox.delete(0, END)
        self.address_ent.delete(0, END)
        self.email_ent.delete(0, END)
        self.phone_ent.delete(0, END)

    def back_butn(self):
        self.window.switch_frame(admin_page)
        self.frame4.destroy()

    def add_staffs(self):
        name = self.name_ent.get()
        passwrd = self.password_ent.get()
        address = self.address_ent.get()
        gender = self.category_combobox.get()
        email = self.email_ent.get()
        phone = self.phone_ent.get()
        age = self.age_spin.get()
        if len(name and passwrd and address and email and phone) > 0:
            if phone.isdigit():
                if stall.inject(name, passwrd, age, gender, address, phone, email):
                    messagebox.showinfo('info', 'Staff is added')
                else:
                    messagebox.showinfo('Info', 'Something is wrong')
            else:
                messagebox.showinfo('Info', 'Contact no. must be in digit')
        else:
            messagebox.showinfo('Error', 'All the required field must be filled')


class edit_staffs(Frame):
    def __init__(self, window):
        Frame.__init__(self, window)
        self.window = window
        self.window.title('Edit Staffs')
        self.canvas = Canvas(self.window, width=2000, height=790)
        self.canvas.place(x=0, y=0)
        self.sequence = [ImageTk.PhotoImage(img)
                         for img in ImageSequence.Iterator(
                Image.open(
                    r'Z:\Algorithm\Final_Assignment\Interface\vodkaaaaaa.gif'))]
        self.image = self.canvas.create_image(760, 400, image=self.sequence[0])
        self.animate(1)

        global index
        self.index = ''
        self.frame5 = Frame(self.window, bg='black')
        self.frame5.place(x=30, y=100)

        # ----------LABEL-------LABEL-----------#
        self.name = Label(self.frame5, text='Staff Name', font='Arial 20 bold').grid(row=0, column=0, pady=10)
        self.password = Label(self.frame5, text='Password', font='Arial 20 bold').grid(row=1, column=0, pady=10)
        self.age = Label(self.frame5, text='Age', font='Arial 20 bold').grid(row=2, column=0, pady=10)
        self.address = Label(self.frame5, text='Location', font='Arial 20 bold').grid(row=3, column=0, pady=10)
        self.sex = Label(self.frame5, text='Gender', font='Arial 20 bold').grid(row=4, column=0, pady=10)
        self.email = Label(self.frame5, text='Email', font='Arial 20 bold').grid(row=5, column=0, pady=10)
        self.phone = Label(self.frame5, text='Contact no.', font='Arial 20 bold').grid(row=6, column=0, pady=10)

        # ----------ENTRY-------ENTRY----------#
        self.name_ent = Entry(self.frame5, font='Arial 20 bold')
        self.name_ent.grid(row=0, column=1, pady=10, padx=10)
        self.password_ent = Entry(self.frame5, font='Arial 20 bold')
        self.password_ent.grid(row=1, column=1, pady=10, padx=10)
        self.age_spin = Spinbox(self.frame5, font='Arial 19 bold', from_=18, to=70)
        self.age_spin.grid(row=2, column=1, pady=10, padx=10)
        self.address_ent = Entry(self.frame5, font='Arial 20 bold')
        self.address_ent.grid(row=3, column=1, pady=10, padx=10)
        self.category_combobox = ttk.Combobox(self.frame5, font='Arial 19 bold', values=('Male', 'Female', 'Others'))
        self.category_combobox.grid(row=4, column=1, pady=10, padx=10)
        self.email_ent = Entry(self.frame5, font='Arial 20 bold')
        self.email_ent.grid(row=5, column=1, pady=10, padx=10)
        self.phone_ent = Entry(self.frame5, font='Arial 20 bold')
        self.phone_ent.grid(row=6, column=1, pady=10, padx=10)
        self.updat = Button(self.frame5, text='Update INFO', font='Arial 20 bold', fg='black',
                            bg='white', width=10, command=self.update_info)
        self.updat.grid(row=7, column=0)
        self.delete_btn = Button(self.frame5, text='DELETE', font='Arial 12 bold', fg='black',
                                 bg='white', width=6, command=self.delete_details)
        self.delete_btn.grid(row=7, column=1)

        self.frame6 = Frame(self.window, bg='black')
        self.frame6.place(x=535, y=115)
        self.staff_tree = ttk.Treeview(self.frame6, selectmode='browse',
                                       )
        ttk.Style().configure('Treeview', rowheight=40)
        self.staff_tree.grid(row=0, column=0)

        self.staff_tree['column'] = ('1', '2', '3', '4', '5', '6', '7')
        self.staff_tree['show'] = 'headings'
        self.staff_tree.column('1', width=140, anchor='c')
        self.staff_tree.column('2', width=140, anchor='se')
        self.staff_tree.column('3', width=140, anchor='se')
        self.staff_tree.column('4', width=140, anchor='se')
        self.staff_tree.column('5', width=140, anchor='se')
        self.staff_tree.column('6', width=140, anchor='se')
        self.staff_tree.column('7', width=140, anchor='se')

        self.staff_tree.heading('1', text='Staff Name')
        self.staff_tree.heading('2', text='Password')
        self.staff_tree.heading('3', text='Age')
        self.staff_tree.heading('4', text='Gender')
        self.staff_tree.heading('5', text='Address')
        self.staff_tree.heading('6', text='Email')
        self.staff_tree.heading('7', text='Contact no.')

        self.show_staff_tree()
        ###### menu#######menu########menu#####
        self.my_menu = Menu(self.frame5, tearoff=True)
        self.my_menu.add_command(label='Back', command=self.back_butn)
        self.master.option_add('*tearOff', False)
        self.window.config(menu=self.my_menu)

    def animate(self, counter):
        self.canvas.itemconfig(self.image, image=self.sequence[counter])
        self.window.after(100, lambda: self.animate((counter + 1) % len(self.sequence)))

    def show_staff_tree(self):
        self.staff_tree.delete(*self.staff_tree.get_children())
        store = stall.eject()
        for i in store:
            self.staff_tree.insert("", "end", text=i[0], values=(i[1], i[2], i[3], i[4], i[5], i[7], i[6]))
        self.staff_tree.bind("<Double-1>", self.selected_category)

    def update_info(self):
        name = self.name_ent.get()
        passwrd = self.password_ent.get()
        address = self.address_ent.get()
        gender = self.category_combobox.get()
        email = self.email_ent.get()
        phone = self.phone_ent.get()
        age = self.age_spin.get()
        if len(name and passwrd and address and email and phone) > 0:
            if phone.isdigit():
                if stall.update_details(self.index, name, passwrd, age, gender, address, phone, email):
                    messagebox.showinfo('info', 'Staff is Updated')
                    self.show_staff_tree()

                else:
                    messagebox.showinfo('Info', 'Something is wrong')
            else:
                messagebox.showinfo('Info', 'Contact no. must be in digit')
        else:
            messagebox.showinfo('Error', 'All the required field must be filled')

    def delete_details(self):
        if stall.delete(self.index):
            self.show_staff_tree()
            messagebox.showinfo('Info', 'Selected Category is deleted')
            self.index = ''
            self.name_ent.delete(0, END)
            self.password_ent.delete(0, END)
            self.age_spin.delete(0, END)
            self.category_combobox.delete(0, END)
            self.address_ent.delete(0, END)
            self.email_ent.delete(0, END)
            self.phone_ent.delete(0, END)

    def selected_category(self, event):
        selected = self.staff_tree.selection()[0]
        selected_details = self.staff_tree.item(selected, 'values')
        self.index = self.staff_tree.item(selected, 'text')

        self.name_ent.delete(0, END)
        self.name_ent.insert(0, selected_details[0])
        self.password_ent.delete(0, END)
        self.password_ent.insert(0, selected_details[1])
        self.age_spin.delete(0, END)
        self.age_spin.insert(0, selected_details[2])
        self.category_combobox.delete(0, END)
        self.category_combobox.insert(0, selected_details[3])
        self.address_ent.delete(0, END)
        self.address_ent.insert(0, selected_details[4])
        self.email_ent.delete(0, END)
        self.email_ent.insert(0, selected_details[5])
        self.phone_ent.delete(0, END)
        self.phone_ent.insert(0, selected_details[6])

    def back_butn(self):
        self.window.switch_frame(staffs)
        self.frame5.destroy()


con = 0
tzt = ''


class search_staffs(Frame):
    def __init__(self, window):
        Frame.__init__(self, window)
        self.window = window
        self.window.title('Search Staffs')
        self.canvas = Canvas(self.window, width=2000, height=790)
        self.canvas.place(x=0, y=0)
        self.sequence = [ImageTk.PhotoImage(img)
                         for img in ImageSequence.Iterator(
                Image.open(
                    r'Z:\Algorithm\Final_Assignment\Interface\vodkaaaaaa.gif'))]
        self.image = self.canvas.create_image(760, 400, image=self.sequence[0])
        self.animate(1)

        global index
        global maintain
        global nam
        global ag
        global email
        global cont
        global gen
        global addre
        global ss
        ss = "Double Tap For Details"
        self.nam = StringVar()
        self.ag = StringVar()
        self.email = StringVar()
        self.cont = StringVar()
        self.gen = StringVar()
        self.addre = StringVar()
        self.nam.set('')
        self.ag.set('')
        self.email.set('')
        self.cont.set('')
        self.gen.set('')
        self.addre.set('')
        self.maintain = []
        self.index = ''

        self.frame6 = Frame(self.window, bg='black')
        self.frame6.place(x=50, y=100)
        # ----------LABEL-------LABEL-----------#
        self.name = Label(self.frame6, text='Staff Name', font='Arial 20 bold').grid(row=1, column=0, pady=10)
        self.name_ent = Entry(self.frame6, font='Arial 17 bold')
        self.name_ent.grid(row=2, column=0, pady=10)
        self.search_btn = Button(self.frame6, text='search', font='Arial 20 bold', command=self.search_pressed)
        self.search_btn.grid(row=3, column=0, pady=10)

        # ----------ENTRY-------ENTRY----------#

        self.my_menu = Menu(self.frame6, tearoff=True)
        self.my_menu.add_command(label='Back', command=self.back_butn)
        self.master.option_add('*tearOff', False)
        self.window.config(menu=self.my_menu)

        # --------TRY-------TRY#
        self.frame3 = Frame(self.window, bg='black')
        self.frame3.place(x=40, y=350)
        self.sliderLabel = Label(self.frame3, text=ss, font='Arial 20 bold', relief=RIDGE, borderwidth=0,
                                 highlightthickness=0)
        self.sliderLabel.grid(row=4, column=1)
        self.IntroLabelTick()

        self.show_tree = ttk.Treeview(self.frame3, selectmode='browse')

        self.show_tree.grid(row=5, column=1)
        self.show_tree['column'] = ('1', '2')
        self.show_tree['show'] = 'headings'
        self.show_tree.column('1', width=200, anchor='c')
        self.show_tree.column('2', width=150, anchor='c')

        self.show_tree.heading('1', text='Staff Name')
        self.show_tree.heading('2', text='Address')

        self.showproduct_tree()

    def animate(self, counter):
        self.canvas.itemconfig(self.image, image=self.sequence[counter])
        self.window.after(100, lambda: self.animate((counter + 1) % len(self.sequence)))

    def IntroLabelTick(self):
        global con, tzt
        if (con >= len(ss)):
            con = -1
            tzt = ''
            self.sliderLabel.config(text=tzt)
        else:
            tzt = tzt + ss[con]
            self.sliderLabel.config(text=tzt)
        con += 1
        self.sliderLabel.after(150, self.IntroLabelTick)

    def search_pressed(self):
        name = self.name_ent.get()
        store = stall.search(name)
        self.show_tree.delete(*self.show_tree.get_children())
        for i in store:
            self.show_tree.insert("", "end", text=i[0], values=(i[1], i[5]))

    def showproduct_tree(self):
        self.show_tree.delete(*self.show_tree.get_children())
        store = stall.eject()
        for i in store:
            self.show_tree.insert("", "end", text=i[0], values=(i[1], i[5]))
        self.show_tree.bind("<Double-1>", self.selected_category)

    def selected_category(self, event):
        selected = self.show_tree.selection()[0]
        selected_details = self.show_tree.item(selected, 'values')
        self.index = self.show_tree.item(selected, 'text')
        self.frame = Frame(self.frame6, bg='black').place(x=700, y=0)
        self.lb = Label(self.frame, text='Staff Details', font='Arial 35 bold').place(x=800, y=50)
        self.name_lb = Label(self.frame, text='Staff Name :', font='Arial 20 bold').place(x=850, y=120)
        self.age_lb = Label(self.frame, text='Age :', font='Arial 20 bold').place(x=850, y=170)
        self.gender_lb = Label(self.frame, text='Gender :', font='Arial 19 bold').place(x=850, y=220)
        self.email_lb = Label(self.frame, text='Email', font='Arial 20 bold').place(x=850, y=270)
        self.contact = Label(self.frame, text='Contact no.', font='Arial 20 bold').place(x=850, y=320)

        self.address = Label(self.frame, text='Address :', font='Arial 19 bold').place(x=850, y=370)
        result = stall.showw(self.index)
        self.maintain.append(result)
        self.name_data = Label(self.frame, textvariable=self.nam, font='Arial 20 bold')
        self.name_data.place(x=1100, y=120)

        self.age_data = Label(self.frame, textvariable=self.ag, font='Arial 20 bold')
        self.age_data.place(x=1100, y=170)

        self.gender_data = Label(self.frame, textvariable=self.gen, font='Arial 20 bold')
        self.gender_data.place(x=1100, y=220)
        self.email_data = Label(self.frame, textvariable=self.email, font='Arial 20 bold')
        self.email_data.place(x=1100, y=270)
        self.contact_data = Label(self.frame, textvariable=self.cont, font='Arial 20 bold')
        self.contact_data.place(x=1100, y=320)
        self.address_data = Label(self.frame, textvariable=self.addre, font='Arial 20 bold')
        self.address_data.place(x=1100, y=370)

        self.nam.set(self.maintain[0][0][1])
        self.ag.set(self.maintain[0][0][3])
        self.gen.set(self.maintain[0][0][4])
        self.email.set(self.maintain[0][0][7])
        self.cont.set(self.maintain[0][0][6])
        self.addre.set(self.maintain[0][0][5])
        self.maintain = []

    def back_butn(self):
        self.window.switch_frame(staffs)
        self.frame6.destroy()


app = App()
app.mainloop()
