from tkinter import *


class staffs:
    pass