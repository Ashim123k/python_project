from Files.database_query import MyDb
class brand_op:
    def __init__(self):
        self.my_db=MyDb()
    def add_brand(self,brand_name,remarks):
        query="INSERT INTO brand (brand_name,remarks) VALUES (%s,%s)"
        values=(brand_name,remarks)
        self.my_db.quv(query,values)
        return True
    def show_brand(self):
        qry="SELECT * FROM brand"
        all_items=self.my_db.show(qry)
        return all_items
    def show_specific(self):
        qry="SELECT brand_name FROM brand"
        all_item=self.my_db.show(qry)
        all_items=[]
        for i in all_item:
            all_items.append(i[0])
        return all_items
    def delete_brand(self,row):
        qry="DELETE FROM brand WHERE id = %s"
        values=(row,)
        self.my_db.quv(qry,values)
        return True
    def update_brand(self,row,name,remarks):
        qry="UPDATE brand SET brand_name = %s, remarks = %s WHERE id = %s"
        values=(name,remarks,row)
        self.my_db.quv(qry,values)
        return True
