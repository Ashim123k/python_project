import mysql.connector


class MyDb:
    def __init__(self):
        self.connection = mysql.connector.connect(user="root",password="",host="localhost",port=3306,database="liquor store")
        self.cursor=self.connection.cursor()

    def quv(self,qry,values):
        self.cursor.execute(qry,values)
        self.connection.commit()

    def show(self,qry):
        self.cursor.execute(qry)
        details=self.cursor.fetchall()
        return details

    def quv_return_id(self,qry,values):
        self.cursor.execute(qry,values)
        self.connection.commit()
        return self.cursor.lastrowid

    def show_data_p(self, qry, values):
        self.cursor.execute(qry, values)
        data = self.cursor.fetchall()
        return data

