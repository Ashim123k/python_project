from Files.database_query import MyDb


class search:
    def __init__(self):
        self.my_db = MyDb()

    def supply_search(self, name):
        qry = """
                     SELECT item_details.id, item_details.price, item_details.Stock,  supply.supplyin,
                supply.amount, supply.remarks, supply.Date, supply.month, supply.year,CONCAT(brand.brand_name ,category.category_name,' - ', item_details.Quantity,' ml ') as Nam 
                FROM supply
                     JOIN item_details ON supply.item_id = item_details.id 
                     JOIN category  ON category.id=item_details.category_id
                     JOIN brand  ON brand.id=item_details.brand_id
                     WHERE brand.brand_name LIKE %s
                     """
        values = (name+'%',)

        all_orders = self.my_db.show_data_p(qry, values)
        return all_orders

    def sale_search(self,name):
        qry = """
                             SELECT  item_details.id, item_details.price, item_details.Stock,  supply_out.supplyout,
                supply_out.amount, supply_out.remarks, supply_out.Date, supply_out.month, supply_out.year,CONCAT(brand.brand_name ,category.category_name,' - ', item_details.Quantity,' ml ') as Name,category.category_name,brand.brand_name,item_details.Quantity,supply_out.id
                FROM supply_out
                JOIN item_details ON supply_out.item_id = item_details.id 
                JOIN category  ON category.id=item_details.category_id
                JOIN brand  ON brand.id=item_details.brand_id
                             WHERE brand.brand_name LIKE %s
                             """
        values = (name + '%',)

        all_orders = self.my_db.show_data_p(qry, values)
        return all_orders

