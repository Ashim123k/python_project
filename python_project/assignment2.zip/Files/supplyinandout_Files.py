from Files.database_query import MyDb
class supply:
    def __init__(self):
        self.my_db=MyDb()

    def supply_in(self, amount,date,month,year, supply_in, remarks,selected_items,index):
        for i in selected_items:
            qry="INSERT INTO supply (item_id, Date, month, year, supplyin, amount, Remarks) VALUES (%s, %s, %s, %s, %s, %s, %s)"
            values=(i[0],date,month,year,supply_in,amount,remarks)
            self.my_db.quv(qry,values)
            self.changestock(supply_in,index)
        return True
    def delete_details(self,row):
        qry="DELETE FROM supply WHERE id = %s"
        values=(row,)
        self.my_db.quv(qry,values)
        return True
    def update_details(self,row,supply,amount,remarks,date,month,year,selected_items):
        for i in selected_items:
            qry="UPDATE supply SET supplyin=%s,amount=%s, Remarks=%s , Date = %s, month = %s, year=%s, item_id=%s WHERE id = %s"
            values=(supply,amount,remarks,date,month,year,i[0],row)
            self.my_db.quv(qry,values)
        return True
    def join_tables(self):
        qry="""SELECT  item_details.Quantity, item_details.Price, item_details.Stock, brand.brand_name, category.category_name FROM item_details
             JOIN brand ON item_details.brand_id = brand.id 
             JOIN category ON item_details.category_id = category.id """

        all_orders = self.my_db.show(qry)
        return all_orders

    def join_table(self):
        qry = """SELECT  item_details.id, item_details.price, item_details.Stock,  supply.supplyin,
                supply.amount, supply.remarks, supply.Date, supply.month, supply.year,CONCAT(brand.brand_name ,category.category_name,' - ', item_details.Quantity,' ml ') as Name,category.category_name,brand.brand_name,item_details.Quantity,supply.id
                FROM supply
                JOIN item_details ON supply.item_id = item_details.id 
                JOIN category  ON category.id=item_details.category_id
                JOIN brand  ON brand.id=item_details.brand_id
                                        """

        all_orders = self.my_db.show(qry)
        return all_orders
    def changestock(self,supply,index):
        qry="UPDATE item_details SET Stock = Stock+%s WHERE id = %s"
        values=(supply,index)
        self.my_db.quv(qry,values)
class supply_out:
    def __init__(self):
        self.my_db=MyDb()

    def supply_out(self, amount,date,month,year, supply_in, remarks,selected_items,index):
        for i in selected_items:
            qry="INSERT INTO supply_out (item_id, Date, month, year, supplyout, amount, Remarks) VALUES (%s, %s, %s, %s, %s, %s, %s)"
            values=(i[0],date,month,year,supply_in,amount,remarks)
            self.my_db.quv(qry,values)
            self.changestock(supply_in,index)
        return True
    def delete_details(self,row):
        qry="DELETE FROM supply_out WHERE id = %s"
        values=(row,)
        self.my_db.quv(qry,values)
        return True
    def update_details(self,row,supply,amount,remarks,date,month,year,selected_items):
        for i in selected_items:
            qry="UPDATE supply_out SET supplyout=%s,amount=%s, Remarks=%s , Date = %s, month = %s, year=%s, item_id=%s WHERE id = %s"
            values=(supply,amount,remarks,date,month,year,i[0],row)
            self.my_db.quv(qry,values)
        return True
    def join_tables(self):
        qry="""SELECT  item_details.Quantity, item_details.Price, item_details.Stock, brand.brand_name, category.category_name FROM item_details
             JOIN brand ON item_details.brand_id = brand.id 
             JOIN category ON item_details.category_id = category.id """

        all_orders = self.my_db.show(qry)
        return all_orders

    def join_table(self):
        qry = """SELECT  item_details.id, item_details.price, item_details.Stock,  supply_out.supplyout,
                supply_out.amount, supply_out.remarks, supply_out.Date, supply_out.month, supply_out.year,CONCAT(brand.brand_name ,category.category_name,' - ', item_details.Quantity,' ml ') as Name,category.category_name,brand.brand_name,item_details.Quantity,supply_out.id
                FROM supply_out
                JOIN item_details ON supply_out.item_id = item_details.id 
                JOIN category  ON category.id=item_details.category_id
                JOIN brand  ON brand.id=item_details.brand_id
                                        """

        all_orders = self.my_db.show(qry)
        return all_orders
    def changestock(self,supply,index):
        qry="UPDATE item_details SET Stock = Stock-%s WHERE id = %s"
        values=(supply,index)
        self.my_db.quv(qry,values)



