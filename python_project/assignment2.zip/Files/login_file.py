from Files.database_query import MyDb


class Log_in:
    def __init__(self):
        self.my_db = MyDb()

    def login(self,name,passw):
        qry = 'SELECT name, passwrd FROM staffs'
        stored=self.my_db.show(qry)
        count=0
        for i in stored:
            if name==i[0] and passw==i[1]:
                count+=1
        return count


