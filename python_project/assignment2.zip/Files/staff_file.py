from Files.database_query import MyDb


class staff:
    def __init__(self):
        self.my_db = MyDb()

    def inject(self, name, passwrd, age, gender, address, phone, email):
        qry = "INSERT INTO staffs (name, passwrd, age, gender, address, email, phone) VALUES (%s, %s, %s, %s, %s, %s, %s)"
        values = (name, passwrd, age, gender, address, email, phone)
        self.my_db.quv(qry, values)
        return True

    def eject(self):
        qry = 'SELECT * FROM staffs'
        result = self.my_db.show(qry)
        return result

    def update_details(self, row, name, passwrd, age, gender, address, phone, email):
        qry = "UPDATE staffs SET name=%s,passwrd=%s, age=%s , gender = %s, address = %s, email=%s, phone=%s WHERE id = %s"
        values = (name, passwrd, age, gender, address, email, phone, row)
        self.my_db.quv(qry, values)
        return True

    def delete(self, row):
        qry = "DELETE FROM staffs WHERE id = %s"
        values = (row,)
        self.my_db.quv(qry, values)
        return True
    def search(self,name):
        qry=""" SELECT * FROM staffs
            WHERE staffs.name LIKE %s
            """
        value=(name+'%',)
        result=self.my_db.show_data_p(qry,value)
        return result
    def showw(self,row):
        qry='SELECT * FROM staffs WHERE id=%s'
        value=(row,)
        result=self.my_db.show_data_p(qry,value)
        return result
