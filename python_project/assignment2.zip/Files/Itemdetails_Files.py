from Files.database_query import MyDb
class details:
    def __init__(self):
        self.my_db=MyDb()

    def items_details(self,quantity,price,stock,remarks,selected_items):
        for i in selected_items:
            if i[1] and i[0]=='':
                return False
            else:
                qry="INSERT INTO item_details (Quantity, Price, Stock, Remarks, category_id, brand_id) VALUES (%s, %s, %s, %s, %s, %s)"
                values=(quantity,price,stock,remarks,i[1],i[0])
                self.my_db.quv(qry,values)


        return True
    def delete_details(self,row):
        qry="DELETE FROM item_details WHERE id = %s"
        values=(row,)
        self.my_db.quv(qry,values)
        return True
    def update_details(self,row,quantity,price,supply,remarks,selected_items):
        for i in selected_items:
            qry="UPDATE item_details SET Quantity=%s,Price=%s, Stock=%s , Remarks = %s, category_id = %s, brand_id=%s WHERE id = %s"
            values=(quantity,price,supply,remarks,i[1],i[0],row)
            self.my_db.quv(qry,values)
        return True
    def join_tables(self,category_id):
        qry="""SELECT category.name=%s, brand.brand_name=%s, item_details.Quantity, item_details.Price, item_details.Stock FROM item_details
             JOIN brand ON item_details.brand_id = brand.id 
             JOIN category ON item_details category_id = category.id
             WHERE brand_id = %s"""
        val = (category_id,)
        all_orders = self.my_db.show_data_p(qry, val)
        return all_orders
    def show_item(self):
        qry = "SELECT * FROM item_details"
        all_items = self.my_db.show(qry)
        return all_items
    def show_specific(self):
        qry = """SELECT item_details.brand_id, item_details.category_id, item_details.Quantity FROM item_details
                 JOIN brand ON item_details.brand_id = brand.id 
                JOIN category ON item_details.category_id = category.id"""
        all_items=self.my_db.show(qry)
        return all_items

    def join_table(self):
        qry = """SELECT  item_details.id, category.category_name, brand.brand_name, item_details.Quantity, item_details.price, item_details.Stock ,item_details.Remarks
                FROM item_details
                JOIN brand ON item_details.brand_id = brand.id 
                JOIN category ON item_details.category_id = category.id"""

        all_orders = self.my_db.show(qry)
        return all_orders
