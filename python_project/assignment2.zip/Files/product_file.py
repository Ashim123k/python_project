from Files.database_query import MyDb

class search:
    def __init__(self):
        self.my_db = MyDb()
    def search_products(self, cat_name):
        qry = """   SELECT  category.category_name, brand.brand_name, item_details.Quantity
                FROM item_details
                JOIN brand ON item_details.brand_id = brand.id 
                JOIN category ON item_details.category_id = category.id
                     WHERE category.category_name LIKE %s
                     """
        values = (cat_name+'%',)
        all_orders = self.my_db.show_data_p(qry, values)
        return all_orders

    def item_detail(self, item_id):
        qry = """   SELECT  category.category_name, brand.brand_name, item_details.Quantity,item_details.Stock,item_details.Price, category.remarks, brand.remarks, item_details.Remarks
                  FROM item_details
                  JOIN brand ON item_details.brand_id = brand.id 
                  JOIN category ON item_details.category_id = category.id
                       WHERE item_details.id = %s
                       """
        values = (item_id,)
        all_orders = self.my_db.show_data_p(qry, values)
        return all_orders
