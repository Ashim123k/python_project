from Files.database_query import MyDb
class cat_op:
    def __init__(self):
        self.my_db=MyDb()
    def add_cat(self,cat_name,remarks):
        query="INSERT INTO category (category_name,remarks) VALUES (%s,%s)"
        values=(cat_name,remarks)
        self.my_db.quv(query,values)
        return True
    def show_category(self):
        qry="SELECT * FROM category"
        all_items=self.my_db.show(qry)
        return all_items
    def show_specific(self):
        qry = "SELECT category_name FROM category"
        all_item = self.my_db.show(qry)
        all_items = []
        for i in all_item:
            all_items.append(i[0])
        return all_items
    def delete_cat(self,row):
        qry="DELETE FROM category WHERE id = %s"
        values=(row,)
        self.my_db.quv(qry,values)
        return True
    def update_cat(self,row,name,remarks):
        qry="UPDATE category SET category_name = %s, remarks = %s WHERE id = %s"
        values=(name,remarks,row)
        self.my_db.quv(qry,values)
        return True
